export interface Product {
  id: number;
  name: string;
  brand: string;
  category: string;
  unit: string;
  isWeighted: boolean;
  costPrice: number;
  sellingPrice: number;
  stockQuantity: number;
  minStockAlert: number;
  colorTag: string;
  isPopular: boolean;
  createdAt: string;
}

export interface Customer {
  id: number;
  name: string;
  phone: string;
  notes: string;
  totalDebt: number;
  creditLimit: number;
  lastTransactionAt: string;
  createdAt: string;
}

export interface SaleItem {
  id: number;
  saleId: number;
  productId: number | null;
  productName: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  subtotal: number;
  profit: number;
}

export interface Sale {
  id: number;
  invoiceNumber: string;
  totalAmount: number;
  totalCost: number;
  totalProfit: number;
  paymentMethod: "cash" | "credit" | "split";
  paidAmount: number;
  creditAmount: number;
  customerId: number | null;
  customerName: string | null;
  itemsCount: number;
  note: string;
  createdAt: string;
  items: SaleItem[];
}

export interface CreditTransaction {
  id: number;
  customerId: number;
  saleId: number | null;
  type: "debt" | "payment";
  amount: number;
  balanceAfter: number;
  note: string;
  createdAt: string;
}

export interface StoreStats {
  todayTotalRevenue: number;
  todayNetProfit: number;
  todayCashInDrawer: number;
  todayCashFromSales: number;
  todayDebtRepayments: number;
  todayNewCredit: number;
  todayInvoicesCount: number;
  totalOutstandingDebt: number;
  lowStockCount: number;
  outOfStockCount: number;
}

export interface CartItem {
  cartKey: string;
  productId: number | null;
  productName: string;
  brand: string;
  unit: string;
  isWeighted: boolean;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  availableStock: number;
}

export interface HeldCart {
  id: string;
  label: string;
  createdAt: string;
  items: CartItem[];
}

export const CATEGORY_LIST = [
  "الكل",
  "حليب ومشتقاته",
  "مواد أساسية",
  "عجائن وحبوب",
  "معلبات وزيوت",
  "مشروبات وعصائر",
  "بسكويت وحلويات",
  "مواد التنظيف",
] as const;

export const ARABIC_QUICK_LETTERS = [
  "أ",
  "ب",
  "ت",
  "ج",
  "ح",
  "خ",
  "ز",
  "س",
  "ش",
  "ط",
  "ع",
  "ف",
  "ق",
  "ك",
  "ل",
  "م",
  "هـ",
  "ي",
];

export function formatDA(amount: number): string {
  const rounded = Math.round(amount * 100) / 100;
  return new Intl.NumberFormat("fr-DZ", {
    minimumFractionDigits: rounded % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(rounded);
}

/**
 * Converts Algerian Dinar (DA) to popular Algerian spoken Centimes/Alf notation
 * e.g. 1250 DA -> "125 ألف سنتيم" | 250 DA -> "25 ألف سنتيم" | 85 DA -> "8500 سنتيم (8 آلاف ونص)"
 */
export function formatAlgerianCentimes(daAmount: number): string {
  if (!daAmount || daAmount <= 0) return "0 سنتيم";
  const alf = daAmount / 10; // 10 DA = 1 Alf (1000 centimes)
  if (daAmount >= 100) {
    const formattedAlf = Number.isInteger(alf) ? alf.toString() : alf.toFixed(1);
    return `${formattedAlf} ألف سنتيم`;
  }
  return `${Math.round(daAmount * 100)} سنتيم`;
}

export function normalizeArabicForSearch(text: string): string {
  return text
    .toLowerCase()
    .replace(/[أإآا]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .trim();
}
