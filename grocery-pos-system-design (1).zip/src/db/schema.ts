import {
  pgTable,
  serial,
  text,
  doublePrecision,
  integer,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand").notNull().default(""),
  category: text("category").notNull(),
  unit: text("unit").notNull().default("حبة"), // حبة | علبة | قارورة | كيس | كغ
  isWeighted: boolean("is_weighted").notNull().default(false),
  costPrice: doublePrecision("cost_price").notNull(),
  sellingPrice: doublePrecision("selling_price").notNull(),
  stockQuantity: doublePrecision("stock_quantity").notNull(),
  minStockAlert: doublePrecision("min_stock_alert").notNull().default(10),
  colorTag: text("color_tag").notNull().default("emerald"),
  isPopular: boolean("is_popular").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().default(""),
  notes: text("notes").notNull().default(""),
  totalDebt: doublePrecision("total_debt").notNull().default(0),
  creditLimit: doublePrecision("credit_limit").notNull().default(15000),
  lastTransactionAt: timestamp("last_transaction_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull(),
  totalAmount: doublePrecision("total_amount").notNull(),
  totalCost: doublePrecision("total_cost").notNull(),
  totalProfit: doublePrecision("total_profit").notNull(),
  paymentMethod: text("payment_method").notNull(), // 'cash' | 'credit' | 'split'
  paidAmount: doublePrecision("paid_amount").notNull(),
  creditAmount: doublePrecision("credit_amount").notNull().default(0),
  customerId: integer("customer_id").references(() => customers.id, {
    onDelete: "set null",
  }),
  customerName: text("customer_name"),
  itemsCount: integer("items_count").notNull(),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const saleItems = pgTable("sale_items", {
  id: serial("id").primaryKey(),
  saleId: integer("sale_id")
    .notNull()
    .references(() => sales.id, { onDelete: "cascade" }),
  productId: integer("product_id").references(() => products.id, {
    onDelete: "set null",
  }),
  productName: text("product_name").notNull(),
  unit: text("unit").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  unitPrice: doublePrecision("unit_price").notNull(),
  costPrice: doublePrecision("cost_price").notNull(),
  subtotal: doublePrecision("subtotal").notNull(),
  profit: doublePrecision("profit").notNull(),
});

export const creditTransactions = pgTable("credit_transactions", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id")
    .notNull()
    .references(() => customers.id, { onDelete: "cascade" }),
  saleId: integer("sale_id").references(() => sales.id, {
    onDelete: "set null",
  }),
  type: text("type").notNull(), // 'debt' | 'payment'
  amount: doublePrecision("amount").notNull(),
  balanceAfter: doublePrecision("balance_after").notNull(),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;

export type Customer = typeof customers.$inferSelect;
export type NewCustomer = typeof customers.$inferInsert;

export type Sale = typeof sales.$inferSelect;
export type SaleItem = typeof saleItems.$inferSelect;
export type CreditTransaction = typeof creditTransactions.$inferSelect;
