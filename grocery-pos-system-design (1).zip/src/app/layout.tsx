import type { Metadata } from "next";
import { Cairo, IBM_Plex_Sans_Arabic, JetBrains_Mono } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["600", "700", "800"],
  variable: "--font-cairo",
  display: "swap",
});

const ibmPlexArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-ibm-arabic",
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "الميزان برو | نظام نقطة البيع (POS) وتسيير محلات المواد الغذائية العامة - الجزائر",
  description:
    "منصة احترافية متكاملة لأصحاب محلات المواد الغذائية في الجزائر (Alimentation Générale): بيع سريع متعدد السلع بدون باركود، إدارة المخزون، دفتر الكريدي، والمحاسبة اليومية بالدينار الجزائري.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${cairo.variable} ${ibmPlexArabic.variable} ${jetbrainsMono.variable}`}
    >
      <body
        style={{
          fontFamily: "var(--font-ibm-arabic), var(--font-cairo), sans-serif",
        }}
        className="bg-[#F4F6F8] text-[#0F172A] antialiased selection:bg-[#047857] selection:text-white"
      >
        {children}
      </body>
    </html>
  );
}
