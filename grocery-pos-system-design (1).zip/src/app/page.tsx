"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  ShoppingCart,
  Package,
  BookOpen,
  BarChart3,
  Store,
  AlertTriangle,
  RefreshCw,
  TrendingUp,
  Wallet,
} from "lucide-react";
import PosTerminalView from "@/components/PosTerminalView";
import InventoryView from "@/components/InventoryView";
import CreditLedgerView from "@/components/CreditLedgerView";
import AccountingDashboardView from "@/components/AccountingDashboardView";
import {
  Product,
  Customer,
  Sale,
  CreditTransaction,
  StoreStats,
  formatDA,
} from "@/types/store";

type ActiveTab = "pos" | "inventory" | "credit" | "dashboard";

const DEFAULT_STATS: StoreStats = {
  todayTotalRevenue: 0,
  todayNetProfit: 0,
  todayCashInDrawer: 0,
  todayCashFromSales: 0,
  todayDebtRepayments: 0,
  todayNewCredit: 0,
  todayInvoicesCount: 0,
  totalOutstandingDebt: 0,
  lowStockCount: 0,
  outOfStockCount: 0,
};

export default function AlimentationPosPage() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("pos");
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [creditTransactions, setCreditTransactions] = useState<
    CreditTransaction[]
  >([]);
  const [stats, setStats] = useState<StoreStats>(DEFAULT_STATS);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchStoreData = useCallback(async (silent = false) => {
    if (!silent) setIsLoading(true);
    else setIsRefreshing(true);

    try {
      const res = await fetch("/api/store", { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setProducts(data.products || []);
        setCustomers(data.customers || []);
        setSales(data.sales || []);
        setCreditTransactions(data.creditTransactions || []);
        setStats(data.stats || DEFAULT_STATS);
      }
    } catch (err) {
      console.error("Failed to fetch store data:", err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchStoreData(false);
  }, [fetchStoreData]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6F8] text-[#0F172A]">
      {/* Sticky Top Command Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-2xs">
        <div className="max-w-[1600px] mx-auto px-3 sm:px-5 py-2.5 flex flex-wrap items-center justify-between gap-3">
          {/* Brand Logo & Store Identity */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 text-white flex items-center justify-center shadow-sm shrink-0">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-heading font-extrabold text-base sm:text-lg text-slate-900 leading-tight">
                  الميزان برو — Alimentation Générale
                </h1>
                <span className="hidden sm:inline-block bg-emerald-100 text-emerald-800 text-[11px] font-extrabold px-2 py-0.5 rounded-full">
                  الجزائر DA
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                نقطة بيع سريعة متعددة السلع • تسيير المخزون • دفتر الكريدي والمحاسبة
              </p>
            </div>
          </div>

          {/* Primary 4-Mode Navigation Tabs */}
          <nav className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200/80 overflow-x-auto max-w-full">
            <button
              type="button"
              onClick={() => setActiveTab("pos")}
              className={`h-10 px-3.5 sm:px-4 rounded-xl font-heading font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                activeTab === "pos"
                  ? "bg-emerald-700 text-white shadow-xs"
                  : "text-slate-700 hover:text-slate-900 hover:bg-white/60"
              }`}
            >
              <ShoppingCart className="w-4 h-4" />
              <span>نقطة البيع والسلة (POS)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("inventory")}
              className={`h-10 px-3.5 sm:px-4 rounded-xl font-heading font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                activeTab === "inventory"
                  ? "bg-emerald-700 text-white shadow-xs"
                  : "text-slate-700 hover:text-slate-900 hover:bg-white/60"
              }`}
            >
              <Package className="w-4 h-4" />
              <span>المخزون والسلع</span>
              {stats.lowStockCount > 0 && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[11px] font-black num-tabular ${
                    activeTab === "inventory"
                      ? "bg-amber-400 text-slate-950"
                      : "bg-amber-500 text-white"
                  }`}
                >
                  {stats.lowStockCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("credit")}
              className={`h-10 px-3.5 sm:px-4 rounded-xl font-heading font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                activeTab === "credit"
                  ? "bg-amber-600 text-white shadow-xs"
                  : "text-slate-700 hover:text-slate-900 hover:bg-white/60"
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>دفتر الكريدي</span>
              {stats.totalOutstandingDebt > 0 && (
                <span
                  className={`hidden md:inline-block px-2 py-0.5 rounded-full text-[11px] font-bold num-tabular ${
                    activeTab === "credit"
                      ? "bg-white/20 text-white"
                      : "bg-amber-100 text-amber-900"
                  }`}
                >
                  {formatDA(stats.totalOutstandingDebt)} د.ج
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("dashboard")}
              className={`h-10 px-3.5 sm:px-4 rounded-xl font-heading font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shrink-0 cursor-pointer ${
                activeTab === "dashboard"
                  ? "bg-slate-900 text-white shadow-xs"
                  : "text-slate-700 hover:text-slate-900 hover:bg-white/60"
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>الأرباح والمحاسبة</span>
            </button>
          </nav>

          {/* Live Daily Summary Pills & Refresh */}
          <div className="hidden xl:flex items-center gap-2">
            <div
              onClick={() => setActiveTab("dashboard")}
              className="cursor-pointer bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl px-3 py-1.5 flex items-center gap-2 transition-colors"
            >
              <Wallet className="w-4 h-4 text-slate-600" />
              <div className="text-xs">
                <span className="text-slate-500 ml-1">مبيعات اليوم:</span>
                <strong className="font-black text-slate-900 num-tabular">
                  {formatDA(stats.todayTotalRevenue)} د.ج
                </strong>
              </div>
            </div>

            <div
              onClick={() => setActiveTab("dashboard")}
              className="cursor-pointer bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl px-3 py-1.5 flex items-center gap-2 transition-colors"
            >
              <TrendingUp className="w-4 h-4 text-emerald-700" />
              <div className="text-xs">
                <span className="text-emerald-800 ml-1">الربح الصافي:</span>
                <strong className="font-black text-emerald-900 num-tabular">
                  +{formatDA(stats.todayNetProfit)} د.ج
                </strong>
              </div>
            </div>

            {stats.lowStockCount > 0 && (
              <button
                type="button"
                onClick={() => setActiveTab("inventory")}
                className="bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-950 rounded-xl px-3 py-1.5 flex items-center gap-1.5 text-xs font-bold transition-colors"
                title="عرض السلع التي قاربت على النفاد"
              >
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>تنبيه نفاد: {stats.lowStockCount}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => fetchStoreData(true)}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              title="تحديث البيانات"
            >
              <RefreshCw
                className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`}
              />
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-3 sm:px-5 py-4">
        {isLoading ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center my-8 max-w-md mx-auto shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto mb-3 animate-pulse">
              <Store className="w-6 h-6" />
            </div>
            <h2 className="font-heading font-bold text-base text-slate-800">
              جاري تحميل واجهة نقطة البيع والمخزون...
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              يتم تجهيز قائمة السلع ودفتر الكريدي وحسابات اليوم
            </p>
          </div>
        ) : (
          <>
            {activeTab === "pos" && (
              <PosTerminalView
                products={products}
                customers={customers}
                onSaleCompleted={() => fetchStoreData(true)}
                onQuickSwitchTab={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === "inventory" && (
              <InventoryView
                products={products}
                onRefresh={() => fetchStoreData(true)}
              />
            )}

            {activeTab === "credit" && (
              <CreditLedgerView
                customers={customers}
                creditTransactions={creditTransactions}
                sales={sales}
                onRefresh={() => fetchStoreData(true)}
              />
            )}

            {activeTab === "dashboard" && (
              <AccountingDashboardView
                sales={sales}
                stats={stats}
                onRefresh={() => fetchStoreData(true)}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
