import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  products,
  customers,
  sales,
  saleItems,
  creditTransactions,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();

    const [allProducts, allCustomers, allSales, allSaleItems, allCreditTx] =
      await Promise.all([
        db.select().from(products).orderBy(desc(products.isPopular), products.id),
        db
          .select()
          .from(customers)
          .orderBy(desc(customers.totalDebt), customers.id),
        db.select().from(sales).orderBy(desc(sales.createdAt), desc(sales.id)),
        db.select().from(saleItems).orderBy(saleItems.id),
        db
          .select()
          .from(creditTransactions)
          .orderBy(desc(creditTransactions.createdAt), desc(creditTransactions.id)),
      ]);

    // Group saleItems by saleId
    const itemsBySaleId = new Map<number, typeof allSaleItems>();
    for (const item of allSaleItems) {
      const list = itemsBySaleId.get(item.saleId) ?? [];
      list.push(item);
      itemsBySaleId.set(item.saleId, list);
    }

    const salesWithItems = allSales.map((s) => ({
      ...s,
      items: itemsBySaleId.get(s.id) ?? [],
    }));

    // Calculate today's metrics
    const now = new Date();
    const startOfToday = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate()
    );

    const todaySales = allSales.filter(
      (s) => new Date(s.createdAt) >= startOfToday
    );

    const todayTotalRevenue = todaySales.reduce(
      (acc, s) => acc + Number(s.totalAmount || 0),
      0
    );
    const todayNetProfit = todaySales.reduce(
      (acc, s) => acc + Number(s.totalProfit || 0),
      0
    );
    const todayCashFromSales = todaySales.reduce(
      (acc, s) => acc + Number(s.paidAmount || 0),
      0
    );
    const todayNewCredit = todaySales.reduce(
      (acc, s) => acc + Number(s.creditAmount || 0),
      0
    );

    const todayDebtRepayments = allCreditTx
      .filter(
        (tx) =>
          tx.type === "payment" && new Date(tx.createdAt) >= startOfToday
      )
      .reduce((acc, tx) => acc + Number(tx.amount || 0), 0);

    const totalOutstandingDebt = allCustomers.reduce(
      (acc, c) => acc + Number(c.totalDebt || 0),
      0
    );

    const lowStockProducts = allProducts.filter(
      (p) => p.stockQuantity <= p.minStockAlert
    );
    const outOfStockProducts = allProducts.filter((p) => p.stockQuantity <= 0);

    return NextResponse.json({
      products: allProducts,
      customers: allCustomers,
      sales: salesWithItems,
      creditTransactions: allCreditTx,
      stats: {
        todayTotalRevenue,
        todayNetProfit,
        todayCashInDrawer: todayCashFromSales + todayDebtRepayments,
        todayCashFromSales,
        todayDebtRepayments,
        todayNewCredit,
        todayInvoicesCount: todaySales.length,
        totalOutstandingDebt,
        lowStockCount: lowStockProducts.length,
        outOfStockCount: outOfStockProducts.length,
      },
    });
  } catch (error) {
    console.error("Error fetching store data:", error);
    return NextResponse.json(
      { error: "تعذر جلب بيانات المحل" },
      { status: 500 }
    );
  }
}
