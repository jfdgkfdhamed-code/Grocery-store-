import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, creditTransactions } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();

    // Case 1: Recording a debt payment (Versement) or manual debt adjustment
    if (body.action === "payment" || body.action === "debt") {
      const customerId = Number(body.customerId);
      const amount = Math.max(0, Number(body.amount) || 0);
      const note = (body.note || "").trim();

      if (!customerId || amount <= 0) {
        return NextResponse.json(
          { error: "يرجى تحديد الزبون وإدخال مبلغ صحيح أكبر من الصفر" },
          { status: 400 }
        );
      }

      const [existingCust] = await db
        .select()
        .from(customers)
        .where(eq(customers.id, customerId));

      if (!existingCust) {
        return NextResponse.json(
          { error: "الزبون غير موجود" },
          { status: 404 }
        );
      }

      const isPayment = body.action === "payment";
      const newDebt = isPayment
        ? Math.max(0, Number((existingCust.totalDebt - amount).toFixed(2)))
        : Number((existingCust.totalDebt + amount).toFixed(2));

      const [updatedCust] = await db
        .update(customers)
        .set({
          totalDebt: newDebt,
          lastTransactionAt: new Date(),
        })
        .where(eq(customers.id, customerId))
        .returning();

      const [tx] = await db
        .insert(creditTransactions)
        .values({
          customerId,
          saleId: null,
          type: isPayment ? "payment" : "debt",
          amount,
          balanceAfter: newDebt,
          note:
            note ||
            (isPayment
              ? "تسديد دفعة نقدية (تخليص كريدي)"
              : "إضافة مبلغ كريدي يدوي"),
        })
        .returning();

      return NextResponse.json({
        customer: updatedCust,
        transaction: tx,
      });
    }

    // Case 2: Creating a new customer
    const name = (body.name || "").trim();
    if (!name) {
      return NextResponse.json(
        { error: "اسم الزبون مطلوب" },
        { status: 400 }
      );
    }

    const initialDebt = Math.max(0, Number(body.initialDebt) || 0);
    const creditLimit = Math.max(1000, Number(body.creditLimit) || 15000);

    const [createdCustomer] = await db
      .insert(customers)
      .values({
        name,
        phone: (body.phone || "").trim(),
        notes: (body.notes || "").trim(),
        totalDebt: initialDebt,
        creditLimit,
      })
      .returning();

    if (initialDebt > 0) {
      await db.insert(creditTransactions).values({
        customerId: createdCustomer.id,
        saleId: null,
        type: "debt",
        amount: initialDebt,
        balanceAfter: initialDebt,
        note: "رصيد كريدي افتتاحي عند فتح الحساب",
      });
    }

    return NextResponse.json({ customer: createdCustomer });
  } catch (error) {
    console.error("Error in customers POST:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء معالجة طلب دفتر الكريدي" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const id = Number(body.id);

    if (!id) {
      return NextResponse.json(
        { error: "معرف الزبون مطلوب" },
        { status: 400 }
      );
    }

    const [existing] = await db
      .select()
      .from(customers)
      .where(eq(customers.id, id));

    if (!existing) {
      return NextResponse.json(
        { error: "الزبون غير موجود" },
        { status: 404 }
      );
    }

    const [updated] = await db
      .update(customers)
      .set({
        name: body.name !== undefined ? body.name.trim() : existing.name,
        phone: body.phone !== undefined ? body.phone.trim() : existing.phone,
        notes: body.notes !== undefined ? body.notes.trim() : existing.notes,
        creditLimit:
          body.creditLimit !== undefined
            ? Math.max(0, Number(body.creditLimit))
            : existing.creditLimit,
      })
      .where(eq(customers.id, id))
      .returning();

    return NextResponse.json({ customer: updated });
  } catch (error) {
    console.error("Error updating customer:", error);
    return NextResponse.json(
      { error: "تعذر تحديث بيانات الزبون" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = Number(searchParams.get("id"));
    if (!id) {
      return NextResponse.json(
        { error: "معرف الزبون مطلوب" },
        { status: 400 }
      );
    }

    await db.delete(customers).where(eq(customers.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting customer:", error);
    return NextResponse.json(
      { error: "تعذر حذف الزبون" },
      { status: 500 }
    );
  }
}
