import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  products,
  customers,
  sales,
  saleItems,
  creditTransactions,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { eq, sql } from "drizzle-orm";

interface CartItemPayload {
  productId: number | null;
  productName: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  costPrice: number;
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();

    const items: CartItemPayload[] = Array.isArray(body.items) ? body.items : [];
    if (items.length === 0) {
      return NextResponse.json(
        { error: "السلة فارغة، يرجى إضافة سلعة واحدة على الأقل" },
        { status: 400 }
      );
    }

    const paymentMethod: "cash" | "credit" | "split" =
      body.paymentMethod === "credit" || body.paymentMethod === "split"
        ? body.paymentMethod
        : "cash";

    let customerId: number | null = body.customerId ? Number(body.customerId) : null;
    const newCustomerName: string = (body.newCustomerName || "").trim();
    const newCustomerPhone: string = (body.newCustomerPhone || "").trim();
    const note: string = (body.note || "").trim();

    // Calculate totals
    let totalAmount = 0;
    let totalCost = 0;

    const preparedItems = items.map((item) => {
      const qty = Math.max(0.05, Number(item.quantity) || 1);
      const uPrice = Math.max(0, Number(item.unitPrice) || 0);
      const cPrice = Math.max(0, Number(item.costPrice) || uPrice * 0.82);
      const subtotal = Number((qty * uPrice).toFixed(2));
      const costTotal = Number((qty * cPrice).toFixed(2));
      const profit = Number((subtotal - costTotal).toFixed(2));

      totalAmount += subtotal;
      totalCost += costTotal;

      return {
        productId: item.productId ? Number(item.productId) : null,
        productName: item.productName || "سلعة",
        unit: item.unit || "حبة",
        quantity: qty,
        unitPrice: uPrice,
        costPrice: cPrice,
        subtotal,
        profit,
      };
    });

    totalAmount = Number(totalAmount.toFixed(2));
    totalCost = Number(totalCost.toFixed(2));
    const totalProfit = Number((totalAmount - totalCost).toFixed(2));

    let paidAmount = totalAmount;
    let creditAmount = 0;

    if (paymentMethod === "credit") {
      paidAmount = 0;
      creditAmount = totalAmount;
    } else if (paymentMethod === "split") {
      const rawPaid = Math.max(0, Number(body.paidAmount) || 0);
      paidAmount = Math.min(totalAmount, rawPaid);
      creditAmount = Number((totalAmount - paidAmount).toFixed(2));
    }

    let customerNameSnapshot = "زبون مباشر (كاش)";

    if (creditAmount > 0) {
      // If creating a new customer directly from POS
      if (!customerId && newCustomerName) {
        const [createdCust] = await db
          .insert(customers)
          .values({
            name: newCustomerName,
            phone: newCustomerPhone,
            notes: "أضيف من واجهة نقطة البيع (POS)",
            totalDebt: 0,
            creditLimit: 15000,
          })
          .returning();
        customerId = createdCust.id;
        customerNameSnapshot = createdCust.name;
      } else if (customerId) {
        const [existingCust] = await db
          .select()
          .from(customers)
          .where(eq(customers.id, customerId));
        if (!existingCust) {
          return NextResponse.json(
            { error: "الزبون المحدد غير موجود في دفتر الكريدي" },
            { status: 400 }
          );
        }
        customerNameSnapshot = existingCust.name;
      } else {
        return NextResponse.json(
          { error: "يرجى اختيار الزبون أو كتابة اسمه لتسجيل الفاتورة في دفتر الكريدي" },
          { status: 400 }
        );
      }
    } else if (customerId) {
      const [existingCust] = await db
        .select()
        .from(customers)
        .where(eq(customers.id, customerId));
      if (existingCust) {
        customerNameSnapshot = existingCust.name;
      }
    }

    // Generate invoice number
    const [{ maxId }] = await db
      .select({ maxId: sql<number>`COALESCE(MAX(${sales.id}), 1000)` })
      .from(sales);
    const invoiceNumber = `FAC-${Number(maxId) + 1001}`;

    // Insert sale
    const [createdSale] = await db
      .insert(sales)
      .values({
        invoiceNumber,
        totalAmount,
        totalCost,
        totalProfit,
        paymentMethod: creditAmount === 0 ? "cash" : paymentMethod,
        paidAmount,
        creditAmount,
        customerId,
        customerName: customerNameSnapshot,
        itemsCount: preparedItems.length,
        note,
      })
      .returning();

    // Insert sale items & deduct stock automatically
    const insertedItems = await db
      .insert(saleItems)
      .values(
        preparedItems.map((item) => ({
          saleId: createdSale.id,
          productId: item.productId,
          productName: item.productName,
          unit: item.unit,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          costPrice: item.costPrice,
          subtotal: item.subtotal,
          profit: item.profit,
        }))
      )
      .returning();

    for (const item of preparedItems) {
      if (item.productId) {
        const [prod] = await db
          .select()
          .from(products)
          .where(eq(products.id, item.productId));
        if (prod) {
          const newStock = Math.max(
            0,
            Number((prod.stockQuantity - item.quantity).toFixed(3))
          );
          await db
            .update(products)
            .set({ stockQuantity: newStock })
            .where(eq(products.id, prod.id));
        }
      }
    }

    // Update customer debt if creditAmount > 0
    if (creditAmount > 0 && customerId) {
      const [cust] = await db
        .select()
        .from(customers)
        .where(eq(customers.id, customerId));

      if (cust) {
        const newDebt = Number((cust.totalDebt + creditAmount).toFixed(2));
        await db
          .update(customers)
          .set({
            totalDebt: newDebt,
            lastTransactionAt: new Date(),
          })
          .where(eq(customers.id, customerId));

        const itemsSummary = preparedItems
          .slice(0, 4)
          .map((i) => `${i.productName} (${i.quantity} ${i.unit})`)
          .join("، ");

        await db.insert(creditTransactions).values({
          customerId,
          saleId: createdSale.id,
          type: "debt",
          amount: creditAmount,
          balanceAfter: newDebt,
          note:
            note ||
            `فاتورة ${invoiceNumber}: ${itemsSummary}${
              preparedItems.length > 4 ? "..." : ""
            }`,
        });
      }
    }

    return NextResponse.json({
      sale: {
        ...createdSale,
        items: insertedItems,
      },
    });
  } catch (error) {
    console.error("Error creating sale:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء تأكيد الفاتورة" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = Number(searchParams.get("id"));
    if (!id) {
      return NextResponse.json({ error: "معرف الفاتورة مطلوب" }, { status: 400 });
    }

    const [existingSale] = await db
      .select()
      .from(sales)
      .where(eq(sales.id, id));

    if (!existingSale) {
      return NextResponse.json(
        { error: "الفاتورة غير موجودة" },
        { status: 404 }
      );
    }

    const items = await db
      .select()
      .from(saleItems)
      .where(eq(saleItems.saleId, id));

    // Restore stock for each item
    for (const item of items) {
      if (item.productId) {
        const [prod] = await db
          .select()
          .from(products)
          .where(eq(products.id, item.productId));
        if (prod) {
          const restoredStock = Number(
            (prod.stockQuantity + item.quantity).toFixed(3)
          );
          await db
            .update(products)
            .set({ stockQuantity: restoredStock })
            .where(eq(products.id, prod.id));
        }
      }
    }

    // Reverse credit if applicable
    if (existingSale.creditAmount > 0 && existingSale.customerId) {
      const [cust] = await db
        .select()
        .from(customers)
        .where(eq(customers.id, existingSale.customerId));
      if (cust) {
        const updatedDebt = Math.max(
          0,
          Number((cust.totalDebt - existingSale.creditAmount).toFixed(2))
        );
        await db
          .update(customers)
          .set({
            totalDebt: updatedDebt,
            lastTransactionAt: new Date(),
          })
          .where(eq(customers.id, cust.id));

        await db.insert(creditTransactions).values({
          customerId: cust.id,
          saleId: null,
          type: "payment",
          amount: existingSale.creditAmount,
          balanceAfter: updatedDebt,
          note: `إلغاء واسترجاع الفاتورة رقم ${existingSale.invoiceNumber}`,
        });
      }
    }

    await db.delete(sales).where(eq(sales.id, id));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting sale:", error);
    return NextResponse.json(
      { error: "تعذر إلغاء الفاتورة" },
      { status: 500 }
    );
  }
}
