import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();

    const name = (body.name || "").trim();
    if (!name) {
      return NextResponse.json(
        { error: "اسم السلعة مطلوب" },
        { status: 400 }
      );
    }

    const unit = body.unit || "حبة";
    const isWeighted = unit === "كغ" || Boolean(body.isWeighted);
    const sellingPrice = Math.max(0, Number(body.sellingPrice) || 0);
    const costPrice = Math.max(
      0,
      Number(body.costPrice) || Math.round(sellingPrice * 0.82)
    );
    const stockQuantity = Math.max(0, Number(body.stockQuantity) || 0);
    const minStockAlert = Math.max(0, Number(body.minStockAlert) || 10);

    const [created] = await db
      .insert(products)
      .values({
        name,
        brand: (body.brand || "").trim(),
        category: body.category || "مواد أساسية",
        unit,
        isWeighted,
        costPrice,
        sellingPrice,
        stockQuantity,
        minStockAlert,
        colorTag: body.colorTag || "emerald",
        isPopular: Boolean(body.isPopular),
      })
      .returning();

    return NextResponse.json({ product: created });
  } catch (error) {
    console.error("Error creating product:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء إضافة السلعة" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();
    const id = Number(body.id);

    if (!id) {
      return NextResponse.json(
        { error: "معرف السلعة مطلوب" },
        { status: 400 }
      );
    }

    const [existing] = await db
      .select()
      .from(products)
      .where(eq(products.id, id));

    if (!existing) {
      return NextResponse.json(
        { error: "السلعة غير موجودة" },
        { status: 404 }
      );
    }

    // If this is a quick restock operation (addStockDelta)
    if (body.addStockDelta !== undefined) {
      const delta = Number(body.addStockDelta) || 0;
      const newStock = Math.max(
        0,
        Number((existing.stockQuantity + delta).toFixed(3))
      );
      const [updated] = await db
        .update(products)
        .set({ stockQuantity: newStock })
        .where(eq(products.id, id))
        .returning();
      return NextResponse.json({ product: updated });
    }

    const unit = body.unit ?? existing.unit;
    const isWeighted =
      body.isWeighted !== undefined ? Boolean(body.isWeighted) : unit === "كغ";

    const [updated] = await db
      .update(products)
      .set({
        name: body.name !== undefined ? body.name.trim() : existing.name,
        brand: body.brand !== undefined ? body.brand.trim() : existing.brand,
        category: body.category ?? existing.category,
        unit,
        isWeighted,
        costPrice:
          body.costPrice !== undefined
            ? Math.max(0, Number(body.costPrice))
            : existing.costPrice,
        sellingPrice:
          body.sellingPrice !== undefined
            ? Math.max(0, Number(body.sellingPrice))
            : existing.sellingPrice,
        stockQuantity:
          body.stockQuantity !== undefined
            ? Math.max(0, Number(body.stockQuantity))
            : existing.stockQuantity,
        minStockAlert:
          body.minStockAlert !== undefined
            ? Math.max(0, Number(body.minStockAlert))
            : existing.minStockAlert,
        isPopular:
          body.isPopular !== undefined
            ? Boolean(body.isPopular)
            : existing.isPopular,
      })
      .where(eq(products.id, id))
      .returning();

    return NextResponse.json({ product: updated });
  } catch (error) {
    console.error("Error updating product:", error);
    return NextResponse.json(
      { error: "تعذر تحديث بيانات السلعة" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = Number(searchParams.get("id"));
    if (!id) {
      return NextResponse.json(
        { error: "معرف السلعة مطلوب" },
        { status: 400 }
      );
    }

    await db.delete(products).where(eq(products.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting product:", error);
    return NextResponse.json(
      { error: "تعذر حذف السلعة" },
      { status: 500 }
    );
  }
}
