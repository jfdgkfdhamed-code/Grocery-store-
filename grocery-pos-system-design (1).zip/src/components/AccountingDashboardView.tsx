"use client";

import React, { useState, useMemo } from "react";
import {
  TrendingUp,
  Wallet,
  Banknote,
  BookOpen,
  FileText,
  RotateCcw,
  Award,
  ChevronDown,
  ChevronUp,
  Printer,
} from "lucide-react";
import {
  Sale,
  StoreStats,
  formatDA,
  formatAlgerianCentimes,
} from "@/types/store";

interface AccountingDashboardViewProps {
  sales: Sale[];
  stats: StoreStats;
  onRefresh: () => void;
}

export default function AccountingDashboardView({
  sales,
  stats,
  onRefresh,
}: AccountingDashboardViewProps) {
  const [expandedSaleId, setExpandedSaleId] = useState<number | null>(
    sales[0]?.id ?? null
  );
  const [paymentFilter, setPaymentFilter] = useState<
    "all" | "cash" | "credit"
  >("all");
  const [isRefundingId, setIsRefundingId] = useState<number | null>(null);

  const profitMarginPercent = useMemo(() => {
    if (!stats.todayTotalRevenue || stats.todayTotalRevenue <= 0) return 0;
    return Math.round(
      (stats.todayNetProfit / stats.todayTotalRevenue) * 1000
    ) / 10;
  }, [stats]);

  // Aggregate top-selling items across all sales
  const topSellingItems = useMemo(() => {
    const map = new Map<
      string,
      {
        name: string;
        unit: string;
        totalQty: number;
        totalRevenue: number;
        totalProfit: number;
      }
    >();

    for (const sale of sales) {
      for (const item of sale.items) {
        const current = map.get(item.productName) || {
          name: item.productName,
          unit: item.unit,
          totalQty: 0,
          totalRevenue: 0,
          totalProfit: 0,
        };
        current.totalQty =
          Math.round((current.totalQty + item.quantity) * 100) / 100;
        current.totalRevenue =
          Math.round((current.totalRevenue + item.subtotal) * 100) / 100;
        current.totalProfit =
          Math.round((current.totalProfit + item.profit) * 100) / 100;
        map.set(item.productName, current);
      }
    }

    return Array.from(map.values())
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 6);
  }, [sales]);

  const filteredSales = useMemo(() => {
    if (paymentFilter === "all") return sales;
    if (paymentFilter === "cash") {
      return sales.filter((s) => s.paymentMethod === "cash");
    }
    return sales.filter(
      (s) => s.paymentMethod === "credit" || s.paymentMethod === "split"
    );
  }, [sales, paymentFilter]);

  const handleRefundSale = async (sale: Sale) => {
    if (
      !window.confirm(
        `هل تريد إلغاء الفاتورة ${sale.invoiceNumber} وإرجاع السلع للمخزون؟`
      )
    ) {
      return;
    }
    setIsRefundingId(sale.id);
    try {
      const res = await fetch(`/api/sales?id=${sale.id}`, {
        method: "DELETE",
      });
      if (res.ok) {
        onRefresh();
      }
    } finally {
      setIsRefundingId(null);
    }
  };

  const maxTopRevenue = topSellingItems[0]?.totalRevenue || 1;

  return (
    <div className="space-y-5">
      {/* 4 Primary Daily Accounting KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Total Sales Today */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500">
              إجمالي مبيعات اليوم (الفواتير)
            </span>
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-slate-900 num-tabular">
              {formatDA(stats.todayTotalRevenue)}
            </span>
            <span className="text-xs font-bold text-slate-600">د.ج</span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500 font-medium">
              {formatAlgerianCentimes(stats.todayTotalRevenue)}
            </span>
            <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded-md font-bold num-tabular">
              {stats.todayInvoicesCount} فاتورة اليوم
            </span>
          </div>
        </div>

        {/* Card 2: Net Profit Today */}
        <div className="bg-gradient-to-l from-emerald-800 to-emerald-700 text-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-emerald-100">
              صافي الربح الحقيقي لليوم (الفائدة)
            </span>
            <div className="w-10 h-10 rounded-xl bg-white/15 text-white flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black num-tabular">
              +{formatDA(stats.todayNetProfit)}
            </span>
            <span className="text-xs font-bold text-emerald-100">د.ج</span>
          </div>
          <div className="mt-2 pt-2 border-t border-white/15 flex items-center justify-between text-xs">
            <span className="text-emerald-100 font-medium">
              {formatAlgerianCentimes(stats.todayNetProfit)}
            </span>
            <span className="bg-white/20 text-white px-2 py-0.5 rounded-md font-bold num-tabular">
              هامش الربح: {profitMarginPercent}%
            </span>
          </div>
        </div>

        {/* Card 3: Cash in Drawer Today */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500">
              السيولة النقدية في الصندوق (كاش)
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Banknote className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-emerald-800 num-tabular">
              {formatDA(stats.todayCashInDrawer)}
            </span>
            <span className="text-xs font-bold text-emerald-700">د.ج</span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 num-tabular">
            <span>مبيعات كاش: {formatDA(stats.todayCashFromSales)}</span>
            <span>+ تسديد ديون: {formatDA(stats.todayDebtRepayments)}</span>
          </div>
        </div>

        {/* Card 4: Credit Sales Today & Total Ledger Debt */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-500">
              مبيعات الكريدي المسجلة اليوم
            </span>
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl font-black text-amber-700 num-tabular">
              {formatDA(stats.todayNewCredit)}
            </span>
            <span className="text-xs font-bold text-amber-700">د.ج</span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">إجمالي ديون الدفتر:</span>
            <span className="font-extrabold text-amber-900 num-tabular">
              {formatDA(stats.totalOutstandingDebt)} د.ج
            </span>
          </div>
        </div>
      </div>

      {/* Main Content Split: Top Selling Products & Full Invoices Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Top Selling & Most Profitable Products (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-4">
            <Award className="w-5 h-5 text-emerald-700" />
            <h2 className="font-heading font-bold text-base text-slate-900">
              السلع الأكثر مبيعاً وأعلى مردودية
            </h2>
          </div>

          {topSellingItems.length === 0 ? (
            <p className="text-xs text-slate-500 py-8 text-center">
              لا توجد مبيعات مسجلة لعرض التحليل.
            </p>
          ) : (
            <div className="space-y-3.5">
              {topSellingItems.map((item, index) => {
                const widthPct = Math.max(
                  12,
                  Math.round((item.totalRevenue / maxTopRevenue) * 100)
                );

                return (
                  <div key={item.name} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-900 font-bold flex items-center justify-center num-tabular text-[11px]">
                          {index + 1}
                        </span>
                        <span className="font-bold text-slate-900">
                          {item.name}
                        </span>
                        <span className="text-slate-500 num-tabular">
                          ({item.totalQty} {item.unit})
                        </span>
                      </div>

                      <div className="text-left num-tabular">
                        <span className="font-extrabold text-slate-900">
                          {formatDA(item.totalRevenue)} د.ج
                        </span>
                        <span className="text-emerald-700 font-bold mr-2">
                          (ربح +{formatDA(item.totalProfit)})
                        </span>
                      </div>
                    </div>

                    <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 rounded-full"
                        style={{ width: `${widthPct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Complete Invoices History Log (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 mb-4">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-slate-800" />
              <h2 className="font-heading font-bold text-base text-slate-900">
                سجل الفواتير والمبيعات ({filteredSales.length})
              </h2>
            </div>

            <div className="flex items-center bg-slate-100 rounded-xl p-1">
              {[
                { id: "all", label: "الكل" },
                { id: "cash", label: "مبيعات كاش" },
                { id: "credit", label: "فواتير كريدي" },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() =>
                    setPaymentFilter(f.id as "all" | "cash" | "credit")
                  }
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                    paymentFilter === f.id
                      ? "bg-white text-slate-900 shadow-2xs"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {filteredSales.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500">
              لا توجد فواتير مطابقة للفلتر المحدد.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-0.5">
              {filteredSales.map((sale) => {
                const isExpanded = expandedSaleId === sale.id;
                const isCash = sale.paymentMethod === "cash";

                return (
                  <div
                    key={sale.id}
                    className="rounded-xl border border-slate-200 overflow-hidden bg-slate-50/40"
                  >
                    <div
                      onClick={() =>
                        setExpandedSaleId(isExpanded ? null : sale.id)
                      }
                      className="p-3.5 bg-white hover:bg-slate-50 cursor-pointer flex flex-wrap items-center justify-between gap-3 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="px-2.5 py-1 rounded-lg bg-slate-900 text-white font-mono text-xs font-bold">
                          {sale.invoiceNumber}
                        </span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-heading font-bold text-sm text-slate-900">
                              {sale.customerName || "زبون مباشر (كاش)"}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                                isCash
                                  ? "bg-emerald-100 text-emerald-800"
                                  : "bg-amber-100 text-amber-900"
                              }`}
                            >
                              {isCash
                                ? "دفع نقدي (كاش)"
                                : sale.paymentMethod === "credit"
                                ? "مسجل في الكريدي"
                                : "دفع جزئي + كريدي"}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 num-tabular mt-0.5">
                            {new Date(sale.createdAt).toLocaleString("ar-DZ")} |
                            عدد المواد: {sale.items.length}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-left">
                          <div className="text-base font-black text-slate-900 num-tabular">
                            {formatDA(sale.totalAmount)} د.ج
                          </div>
                          <div className="text-[11px] font-bold text-emerald-700 num-tabular">
                            ربح صافي: +{formatDA(sale.totalProfit)} د.ج
                          </div>
                        </div>

                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {/* Expanded Invoice Items Breakdown */}
                    {isExpanded && (
                      <div className="p-3.5 border-t border-slate-200 bg-slate-50 space-y-3">
                        <div className="overflow-x-auto">
                          <table className="w-full text-right text-xs">
                            <thead>
                              <tr className="text-slate-500 border-b border-slate-200">
                                <th className="pb-1.5">السلعة</th>
                                <th className="pb-1.5">الكمية / الوزن</th>
                                <th className="pb-1.5">سعر الوحدة</th>
                                <th className="pb-1.5">المجموع</th>
                                <th className="pb-1.5">الربح</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-200/60">
                              {sale.items.map((item) => (
                                <tr key={item.id}>
                                  <td className="py-1.5 font-bold text-slate-800">
                                    {item.productName}
                                  </td>
                                  <td className="py-1.5 num-tabular font-semibold">
                                    {item.quantity} {item.unit}
                                  </td>
                                  <td className="py-1.5 num-tabular">
                                    {formatDA(item.unitPrice)} د.ج
                                  </td>
                                  <td className="py-1.5 num-tabular font-bold text-slate-900">
                                    {formatDA(item.subtotal)} د.ج
                                  </td>
                                  <td className="py-1.5 num-tabular font-bold text-emerald-700">
                                    +{formatDA(item.profit)} د.ج
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                          <button
                            type="button"
                            onClick={() => window.print()}
                            className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-xs font-bold flex items-center gap-1.5"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>طباعة الفاتورة</span>
                          </button>

                          <button
                            type="button"
                            disabled={isRefundingId === sale.id}
                            onClick={() => handleRefundSale(sale)}
                            className="px-3 py-1.5 rounded-lg bg-red-50 hover:bg-red-600 text-red-700 hover:text-white border border-red-200 text-xs font-bold flex items-center gap-1.5 transition-colors"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>
                              {isRefundingId === sale.id
                                ? "جاري الاسترجاع..."
                                : "إلغاء الفاتورة وإرجاع المخزون"}
                            </span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
