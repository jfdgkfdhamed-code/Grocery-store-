"use client";

import React, { useState, useMemo } from "react";
import {
  Package,
  AlertTriangle,
  Plus,
  Search,
  Edit3,
  Trash2,
  Scale,
  Star,
  Check,
  X,
  ArrowUpCircle,
} from "lucide-react";
import {
  Product,
  CATEGORY_LIST,
  formatDA,
  normalizeArabicForSearch,
} from "@/types/store";

interface InventoryViewProps {
  products: Product[];
  onRefresh: () => void;
}

export default function InventoryView({
  products,
  onRefresh,
}: InventoryViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("الكل");
  const [stockFilter, setStockFilter] = useState<"all" | "low" | "out">("all");

  // Modal state for adding / editing a product
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const [formName, setFormName] = useState("");
  const [formBrand, setFormBrand] = useState("");
  const [formCategory, setFormCategory] = useState("مواد أساسية");
  const [formUnit, setFormUnit] = useState("علبة");
  const [formCostPrice, setFormCostPrice] = useState("");
  const [formSellingPrice, setFormSellingPrice] = useState("");
  const [formStockQuantity, setFormStockQuantity] = useState("");
  const [formMinAlert, setFormMinAlert] = useState("10");
  const [formIsPopular, setFormIsPopular] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [restockingId, setRestockingId] = useState<number | null>(null);

  const lowStockList = useMemo(
    () => products.filter((p) => p.stockQuantity <= p.minStockAlert),
    [products]
  );

  const outOfStockList = useMemo(
    () => products.filter((p) => p.stockQuantity <= 0),
    [products]
  );

  const totalInventoryValue = useMemo(
    () =>
      products.reduce(
        (acc, p) => acc + p.stockQuantity * p.sellingPrice,
        0
      ),
    [products]
  );

  const filteredProducts = useMemo(() => {
    const q = normalizeArabicForSearch(searchQuery);
    return products.filter((p) => {
      if (selectedCategory !== "الكل" && p.category !== selectedCategory) {
        return false;
      }
      if (stockFilter === "low" && p.stockQuantity > p.minStockAlert) {
        return false;
      }
      if (stockFilter === "out" && p.stockQuantity > 0) {
        return false;
      }
      if (q) {
        return (
          normalizeArabicForSearch(p.name).includes(q) ||
          normalizeArabicForSearch(p.brand).includes(q) ||
          normalizeArabicForSearch(p.category).includes(q)
        );
      }
      return true;
    });
  }, [products, searchQuery, selectedCategory, stockFilter]);

  const openAddModal = () => {
    setEditingProduct(null);
    setFormName("");
    setFormBrand("");
    setFormCategory("مواد أساسية");
    setFormUnit("علبة");
    setFormCostPrice("");
    setFormSellingPrice("");
    setFormStockQuantity("24");
    setFormMinAlert("10");
    setFormIsPopular(false);
    setIsModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormName(product.name);
    setFormBrand(product.brand);
    setFormCategory(product.category);
    setFormUnit(product.unit);
    setFormCostPrice(String(product.costPrice));
    setFormSellingPrice(String(product.sellingPrice));
    setFormStockQuantity(String(product.stockQuantity));
    setFormMinAlert(String(product.minStockAlert));
    setFormIsPopular(product.isPopular);
    setIsModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formSellingPrice) return;
    setIsSaving(true);

    try {
      const payload = {
        id: editingProduct?.id,
        name: formName,
        brand: formBrand,
        category: formCategory,
        unit: formUnit,
        isWeighted: formUnit === "كغ",
        costPrice: Number(formCostPrice) || Number(formSellingPrice) * 0.82,
        sellingPrice: Number(formSellingPrice),
        stockQuantity: Number(formStockQuantity) || 0,
        minStockAlert: Number(formMinAlert) || 10,
        isPopular: formIsPopular,
      };

      const res = await fetch("/api/products", {
        method: editingProduct ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setIsModalOpen(false);
        onRefresh();
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleQuickRestock = async (productId: number, delta: number) => {
    setRestockingId(productId);
    try {
      await fetch("/api/products", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: productId, addStockDelta: delta }),
      });
      onRefresh();
    } finally {
      setRestockingId(null);
    }
  };

  const handleDeleteProduct = async (product: Product) => {
    if (!window.confirm(`هل أنت متأكد من حذف "${product.name}" من المخزون؟`)) {
      return;
    }
    await fetch(`/api/products?id=${product.id}`, { method: "DELETE" });
    onRefresh();
  };

  return (
    <div className="space-y-4">
      {/* Top Inventory KPIs & Low-Stock Alerts Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              إجمالي السلع المسجلة
            </p>
            <p className="text-2xl font-black text-slate-900 num-tabular mt-1">
              {products.length} <span className="text-xs font-bold">صنف</span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <Package className="w-6 h-6" />
          </div>
        </div>

        <button
          type="button"
          onClick={() =>
            setStockFilter(stockFilter === "low" ? "all" : "low")
          }
          className={`text-right rounded-xl border-2 p-4 flex items-center justify-between transition-all cursor-pointer ${
            stockFilter === "low"
              ? "bg-amber-600 text-white border-amber-600 shadow-sm"
              : lowStockList.length > 0
              ? "bg-amber-50 border-amber-300 text-amber-950 hover:bg-amber-100"
              : "bg-white border-slate-200 text-slate-800"
          }`}
        >
          <div>
            <p
              className={`text-xs font-bold ${
                stockFilter === "low" ? "text-amber-100" : "text-amber-800"
              }`}
            >
              تنبيهات قرب النفاد (اضغط للفلترة)
            </p>
            <p className="text-2xl font-black num-tabular mt-1">
              {lowStockList.length}{" "}
              <span className="text-xs font-bold">سلعة تحتاج تموين</span>
            </p>
          </div>
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center ${
              stockFilter === "low"
                ? "bg-white/20 text-white"
                : "bg-amber-200/70 text-amber-900"
            }`}
          >
            <AlertTriangle className="w-6 h-6" />
          </div>
        </button>

        <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              سلع نافدة تماماً (0)
            </p>
            <p className="text-2xl font-black text-red-600 num-tabular mt-1">
              {outOfStockList.length}{" "}
              <span className="text-xs font-bold text-slate-500">سلعة</span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              القيمة البيعية للمخزون الحالي
            </p>
            <p className="text-2xl font-black text-emerald-800 num-tabular mt-1">
              {formatDA(totalInventoryValue)}{" "}
              <span className="text-xs font-bold">د.ج</span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <ArrowUpCircle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Low Stock Alert Strip */}
      {lowStockList.length > 0 && (
        <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0" />
            <div>
              <h3 className="font-heading font-bold text-sm text-amber-950">
                تنبيه المخزون: توجد {lowStockList.length} سلع وصلت للحد الأدنى وتحتاج طلب من الموزع:
              </h3>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {lowStockList.map((item) => (
                  <span
                    key={item.id}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white border border-amber-300 text-xs font-bold text-amber-950"
                  >
                    <span>{item.name}</span>
                    <span className="bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded text-[11px] num-tabular">
                      بقي {item.stockQuantity} {item.unit}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleQuickRestock(item.id, 24)}
                      className="text-emerald-700 hover:text-emerald-900 underline text-[11px] mr-1"
                    >
                      +24 سريع
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Search, Category Filter & Add New Product Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-3.5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="flex flex-1 flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن سلعة أو ماركة في المخزون..."
              className="w-full h-10 pr-9 pl-4 bg-slate-50 rounded-xl border border-slate-200 text-sm focus:outline-none focus:border-emerald-600"
            />
          </div>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="h-10 px-3 bg-slate-50 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 focus:outline-none focus:border-emerald-600"
          >
            {CATEGORY_LIST.map((cat) => (
              <option key={cat} value={cat}>
                {cat === "الكل" ? "جميع التصنيفات" : cat}
              </option>
            ))}
          </select>

          <div className="flex items-center bg-slate-100 rounded-xl p-1">
            {[
              { id: "all", label: "الكل" },
              { id: "low", label: `تنبيه النفاد (${lowStockList.length})` },
              { id: "out", label: `نافد (${outOfStockList.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() =>
                  setStockFilter(tab.id as "all" | "low" | "out")
                }
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  stockFilter === tab.id
                    ? "bg-white text-slate-900 shadow-2xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={openAddModal}
          className="h-10 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة سلعة جديدة للمحل</span>
        </button>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-900 text-white text-xs font-bold">
                <th className="py-3 px-4">السلعة والماركة</th>
                <th className="py-3 px-3">التصنيف</th>
                <th className="py-3 px-3">سعر الشراء</th>
                <th className="py-3 px-3">سعر البيع</th>
                <th className="py-3 px-3">ربح الوحدة</th>
                <th className="py-3 px-3">المخزون الحالي</th>
                <th className="py-3 px-3">تزويد سريع (وصول سلعة)</th>
                <th className="py-3 px-4 text-left">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredProducts.map((product) => {
                const unitProfit =
                  Math.round((product.sellingPrice - product.costPrice) * 100) /
                  100;
                const isLow =
                  product.stockQuantity > 0 &&
                  product.stockQuantity <= product.minStockAlert;
                const isOut = product.stockQuantity <= 0;

                return (
                  <tr
                    key={product.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      isOut
                        ? "bg-red-50/40"
                        : isLow
                        ? "bg-amber-50/40"
                        : ""
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {product.isPopular && (
                          <Star className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
                        )}
                        <div>
                          <div className="font-heading font-bold text-slate-900">
                            {product.name}
                          </div>
                          <div className="text-xs text-slate-500 flex items-center gap-1.5">
                            <span>{product.brand || "بدون ماركة"}</span>
                            {product.isWeighted && (
                              <span className="inline-flex items-center gap-0.5 text-[10px] bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded font-bold">
                                <Scale className="w-2.5 h-2.5" /> ميزان (كغ)
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold">
                        {product.category}
                      </span>
                    </td>

                    <td className="py-3 px-3 num-tabular font-semibold text-slate-600">
                      {formatDA(product.costPrice)} د.ج
                    </td>

                    <td className="py-3 px-3 num-tabular font-extrabold text-slate-900">
                      {formatDA(product.sellingPrice)} د.ج
                    </td>

                    <td className="py-3 px-3 num-tabular font-bold text-emerald-700">
                      +{formatDA(unitProfit)} د.ج
                    </td>

                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2.5 py-1 rounded-lg text-xs font-extrabold num-tabular ${
                            isOut
                              ? "bg-red-100 text-red-800"
                              : isLow
                              ? "bg-amber-100 text-amber-900 border border-amber-300"
                              : "bg-emerald-50 text-emerald-800"
                          }`}
                        >
                          {product.stockQuantity} {product.unit}
                        </span>
                        {isLow && (
                          <span className="text-[11px] font-bold text-amber-700">
                            قارب على النفاد!
                          </span>
                        )}
                        {isOut && (
                          <span className="text-[11px] font-bold text-red-700">
                            نفد!
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1">
                        {[6, 12, 24].map((qty) => (
                          <button
                            key={qty}
                            type="button"
                            disabled={restockingId === product.id}
                            onClick={() => handleQuickRestock(product.id, qty)}
                            className="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-700 hover:text-white text-emerald-900 border border-emerald-200 text-xs font-bold num-tabular transition-colors"
                            title={`إضافة ${qty} ${product.unit} للمخزون`}
                          >
                            +{qty}
                          </button>
                        ))}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-left">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => openEditModal(product)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                          title="تعديل السلعة"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteProduct(product)}
                          className="p-1.5 rounded-lg bg-red-50 hover:bg-red-600 text-red-600 hover:text-white transition-colors"
                          title="حذف السلعة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">
                {editingProduct
                  ? `تعديل سلعة: ${editingProduct.name}`
                  : "إضافة سلعة جديدة للمخزون"}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="mt-4 space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    اسم السلعة (بالعربية) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="مثلاً: سكر سيفيتال 1 كغ"
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-medium focus:outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الماركة / الوصف (اختياري)
                  </label>
                  <input
                    type="text"
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    placeholder="مثلاً: Cevital 1Kg"
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-medium focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    التصنيف
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold focus:outline-none focus:border-emerald-600"
                  >
                    {CATEGORY_LIST.filter((c) => c !== "الكل").map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    وحدة البيع (حبة / علبة / كغ بالميزان)
                  </label>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold focus:outline-none focus:border-emerald-600"
                  >
                    <option value="علبة">علبة</option>
                    <option value="كيس">كيس</option>
                    <option value="قارورة">قارورة</option>
                    <option value="حبة">حبة</option>
                    <option value="كغ">كغ (بيع بالميزان ⚖️)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    سعر الشراء بالجملة (د.ج)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={formCostPrice}
                    onChange={(e) => setFormCostPrice(e.target.value)}
                    placeholder="مثلاً: 92"
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold num-tabular focus:outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-emerald-800 mb-1">
                    سعر البيع للزبون (د.ج) *
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    required
                    value={formSellingPrice}
                    onChange={(e) => setFormSellingPrice(e.target.value)}
                    placeholder="مثلاً: 105"
                    className="w-full h-10 px-3 bg-emerald-50/50 rounded-xl border-2 border-emerald-500 text-sm font-extrabold num-tabular focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    الكمية المتوفرة حالياً في المخزون
                  </label>
                  <input
                    type="number"
                    step="0.25"
                    value={formStockQuantity}
                    onChange={(e) => setFormStockQuantity(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold num-tabular focus:outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    حد التنبيه عند قرب النفاد
                  </label>
                  <input
                    type="number"
                    value={formMinAlert}
                    onChange={(e) => setFormMinAlert(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold num-tabular focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={formIsPopular}
                  onChange={(e) => setFormIsPopular(e.target.checked)}
                  className="w-4 h-4 accent-emerald-700 rounded"
                />
                <span className="text-xs font-bold text-slate-700">
                  تمييز ضمن &ldquo;السلع الأكثر طلباً يومياً ⭐&rdquo; لظهورها في مقدمة نقطة البيع
                </span>
              </label>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 h-10 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-6 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSaving ? "جاري الحفظ..." : "حفظ السلعة"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
