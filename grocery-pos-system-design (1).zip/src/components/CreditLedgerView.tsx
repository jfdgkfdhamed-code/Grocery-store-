"use client";

import React, { useState, useMemo } from "react";
import {
  BookOpen,
  UserPlus,
  Search,
  Banknote,
  Phone,
  FileText,
  CheckCircle2,
  PlusCircle,
  X,
  ArrowDownLeft,
  ArrowUpRight,
  Trash2,
} from "lucide-react";
import {
  Customer,
  CreditTransaction,
  Sale,
  formatDA,
  formatAlgerianCentimes,
  normalizeArabicForSearch,
} from "@/types/store";

interface CreditLedgerViewProps {
  customers: Customer[];
  creditTransactions: CreditTransaction[];
  sales: Sale[];
  onRefresh: () => void;
}

export default function CreditLedgerView({
  customers,
  creditTransactions,
  sales,
  onRefresh,
}: CreditLedgerViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
    customers[0] || null
  );

  // Payment / Debt Modal
  const [txModalMode, setTxModalMode] = useState<"payment" | "debt" | null>(
    null
  );
  const [txCustomer, setTxCustomer] = useState<Customer | null>(null);
  const [txAmount, setTxAmount] = useState("");
  const [txNote, setTxNote] = useState("");
  const [isProcessingTx, setIsProcessingTx] = useState(false);

  // New Customer Modal
  const [isNewCustModalOpen, setIsNewCustModalOpen] = useState(false);
  const [newCustName, setNewCustName] = useState("");
  const [newCustPhone, setNewCustPhone] = useState("");
  const [newCustNotes, setNewCustNotes] = useState("");
  const [newCustInitialDebt, setNewCustInitialDebt] = useState("");
  const [newCustLimit, setNewCustLimit] = useState("15000");

  const totalDebtAll = useMemo(
    () => customers.reduce((acc, c) => acc + c.totalDebt, 0),
    [customers]
  );

  const activeDebtorsCount = useMemo(
    () => customers.filter((c) => c.totalDebt > 0).length,
    [customers]
  );

  const filteredCustomers = useMemo(() => {
    const q = normalizeArabicForSearch(searchQuery);
    if (!q) return customers;
    return customers.filter(
      (c) =>
        normalizeArabicForSearch(c.name).includes(q) ||
        c.phone.includes(q) ||
        normalizeArabicForSearch(c.notes).includes(q)
    );
  }, [customers, searchQuery]);

  // Keep selectedCustomer synced with updated customers list
  const activeCustomer = useMemo(() => {
    if (!selectedCustomer) return customers[0] || null;
    return (
      customers.find((c) => c.id === selectedCustomer.id) ||
      customers[0] ||
      null
    );
  }, [customers, selectedCustomer]);

  const customerHistory = useMemo(() => {
    if (!activeCustomer) return [];
    return creditTransactions.filter(
      (tx) => tx.customerId === activeCustomer.id
    );
  }, [creditTransactions, activeCustomer]);

  const customerCreditSales = useMemo(() => {
    if (!activeCustomer) return [];
    return sales.filter((s) => s.customerId === activeCustomer.id);
  }, [sales, activeCustomer]);

  const openTxModal = (cust: Customer, mode: "payment" | "debt") => {
    setTxCustomer(cust);
    setTxModalMode(mode);
    setTxAmount(mode === "payment" && cust.totalDebt > 0 ? String(cust.totalDebt) : "");
    setTxNote("");
  };

  const handleConfirmTx = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!txCustomer || !txModalMode) return;
    const amount = Number(txAmount);
    if (!amount || amount <= 0) return;

    setIsProcessingTx(true);
    try {
      const res = await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: txModalMode,
          customerId: txCustomer.id,
          amount,
          note: txNote,
        }),
      });
      if (res.ok) {
        setTxModalMode(null);
        onRefresh();
      }
    } finally {
      setIsProcessingTx(false);
    }
  };

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim()) return;
    setIsProcessingTx(true);

    try {
      const res = await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newCustName,
          phone: newCustPhone,
          notes: newCustNotes,
          initialDebt: Number(newCustInitialDebt) || 0,
          creditLimit: Number(newCustLimit) || 15000,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setIsNewCustModalOpen(false);
        setNewCustName("");
        setNewCustPhone("");
        setNewCustNotes("");
        setNewCustInitialDebt("");
        setSelectedCustomer(data.customer);
        onRefresh();
      }
    } finally {
      setIsProcessingTx(false);
    }
  };

  const handleDeleteCustomer = async (cust: Customer) => {
    if (
      !window.confirm(
        `هل أنت متأكد من حذف حساب "${cust.name}" من دفتر الكريدي؟`
      )
    ) {
      return;
    }
    await fetch(`/api/customers?id=${cust.id}`, { method: "DELETE" });
    onRefresh();
  };

  return (
    <div className="space-y-4">
      {/* Top Summary Banner for Credit Ledger */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-gradient-to-l from-amber-700 to-amber-600 text-white rounded-xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-amber-100">
              إجمالي أموال الكريدي لدى الزبائن
            </p>
            <p className="text-3xl font-black num-tabular mt-1">
              {formatDA(totalDebtAll)}{" "}
              <span className="text-sm font-bold">د.ج</span>
            </p>
            <p className="text-xs font-bold text-amber-200 mt-0.5">
              يعادل: {formatAlgerianCentimes(totalDebtAll)}
            </p>
          </div>
          <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              عدد الزبائن المسجلين في الدفتر
            </p>
            <p className="text-2xl font-black text-slate-900 num-tabular mt-1">
              {customers.length} زبون{" "}
              <span className="text-xs font-bold text-amber-700">
                ({activeDebtorsCount} عليهم دين حالي)
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsNewCustModalOpen(true)}
            className="h-10 px-3.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ زبون جديد</span>
          </button>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-500">
              إجمالي حركات التسديد المسجلة
            </p>
            <p className="text-2xl font-black text-emerald-700 num-tabular mt-1">
              {
                creditTransactions.filter((tx) => tx.type === "payment").length
              }{" "}
              <span className="text-xs font-bold text-slate-500">
                عملية تسديد
              </span>
            </p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <Banknote className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Split View: Customers List (Right) & Selected Customer Account Details (Left) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Customers List (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="p-3.5 border-b border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <h2 className="font-heading font-bold text-base text-slate-900">
                قائمة زبائن الكريدي ({filteredCustomers.length})
              </h2>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث باسم الزبون أو رقم الهاتف أو العمارة..."
                className="w-full h-10 pr-9 pl-3 bg-slate-50 rounded-xl border border-slate-200 text-xs font-medium focus:outline-none focus:border-amber-600"
              />
            </div>
          </div>

          <div className="divide-y divide-slate-100 max-h-[540px] overflow-y-auto">
            {filteredCustomers.map((cust) => {
              const isSelected = activeCustomer?.id === cust.id;
              const usagePercent = Math.min(
                100,
                Math.round((cust.totalDebt / (cust.creditLimit || 15000)) * 100)
              );

              return (
                <div
                  key={cust.id}
                  onClick={() => setSelectedCustomer(cust)}
                  className={`p-3.5 cursor-pointer transition-colors ${
                    isSelected
                      ? "bg-amber-50/90 border-r-4 border-amber-600"
                      : "hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-heading font-bold text-sm text-slate-900">
                        {cust.name}
                      </h3>
                      {cust.notes && (
                        <p className="text-xs text-slate-500 mt-0.5">
                          {cust.notes}
                        </p>
                      )}
                      {cust.phone && (
                        <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-1 num-tabular">
                          <Phone className="w-3 h-3" />
                          <span>{cust.phone}</span>
                        </p>
                      )}
                    </div>

                    <div className="text-left shrink-0">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-xl text-sm font-black num-tabular ${
                          cust.totalDebt > 0
                            ? "bg-amber-100 text-amber-950"
                            : "bg-emerald-100 text-emerald-800"
                        }`}
                      >
                        {formatDA(cust.totalDebt)} د.ج
                      </span>
                      <div className="mt-1.5 flex items-center justify-end gap-1">
                        {cust.totalDebt > 0 && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              openTxModal(cust, "payment");
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold transition-colors"
                          >
                            تسديد دفعة
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Credit Ceiling Progress Bar */}
                  <div className="mt-2.5">
                    <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                      <span>نسبة استهلاك سقف الكريدي</span>
                      <span className="num-tabular">
                        {formatDA(cust.totalDebt)} / {formatDA(cust.creditLimit)}{" "}
                        د.ج ({usagePercent}%)
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          usagePercent >= 85
                            ? "bg-red-600"
                            : usagePercent >= 50
                            ? "bg-amber-500"
                            : "bg-emerald-600"
                        }`}
                        style={{ width: `${usagePercent}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Customer Detailed Ledger & Invoices (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
          {!activeCustomer ? (
            <div className="py-16 text-center text-slate-500">
              اختر زبوناً من القائمة لعرض كشف حساب الكريدي والفواتير الخاصة به.
            </div>
          ) : (
            <div className="space-y-5">
              {/* Customer Header & Quick Action Buttons */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-heading font-extrabold text-xl text-slate-900">
                      {activeCustomer.name}
                    </h2>
                    <button
                      type="button"
                      onClick={() => handleDeleteCustomer(activeCustomer)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg"
                      title="حذف حساب الزبون"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {activeCustomer.notes || "زبون مسجل في دفتر الكريدي"} | الهاتف:{" "}
                    {activeCustomer.phone || "غير مسجل"}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => openTxModal(activeCustomer, "payment")}
                    className="h-11 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-colors"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>تسديد دفعة (تخليص دين)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => openTxModal(activeCustomer, "debt")}
                    className="h-11 px-3.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>+ إضافة دين يدوي</span>
                  </button>
                </div>
              </div>

              {/* Current Debt Highlight Box */}
              <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold text-amber-900">
                    إجمالي المبلغ المطلوب من الزبون حالياً:
                  </p>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-3xl font-black text-amber-950 num-tabular">
                      {formatDA(activeCustomer.totalDebt)}
                    </span>
                    <span className="text-sm font-bold text-amber-900">
                      د.ج (DA)
                    </span>
                    <span className="text-xs font-bold bg-amber-200/80 text-amber-950 px-2 py-0.5 rounded-md mr-2">
                      {formatAlgerianCentimes(activeCustomer.totalDebt)}
                    </span>
                  </div>
                </div>

                {activeCustomer.totalDebt > 0 && (
                  <button
                    type="button"
                    onClick={() => openTxModal(activeCustomer, "payment")}
                    className="px-4 py-2 rounded-xl bg-white hover:bg-emerald-700 hover:text-white text-emerald-800 border border-emerald-300 font-bold text-xs transition-colors"
                  >
                    تصفير الحساب بالكامل ({formatDA(activeCustomer.totalDebt)} د.ج)
                  </button>
                )}
              </div>

              {/* Customer Credit Invoices with Detailed Purchased Items */}
              {customerCreditSales.length > 0 && (
                <div>
                  <h3 className="font-heading font-bold text-sm text-slate-800 mb-2.5 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-amber-700" />
                    <span>
                      فواتير المشتريات المسجلة على الزبون ({customerCreditSales.length})
                    </span>
                  </h3>
                  <div className="space-y-2 max-h-56 overflow-y-auto">
                    {customerCreditSales.map((sale) => (
                      <div
                        key={sale.id}
                        className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                      >
                        <div className="flex items-center justify-between font-bold text-slate-900 mb-1.5">
                          <span>
                            فاتورة {sale.invoiceNumber} —{" "}
                            <span className="text-slate-500 font-normal">
                              {new Date(sale.createdAt).toLocaleString("ar-DZ")}
                            </span>
                          </span>
                          <span className="text-amber-900 font-extrabold num-tabular">
                            كريدي: {formatDA(sale.creditAmount)} د.ج
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {sale.items.map((item) => (
                            <span
                              key={item.id}
                              className="px-2 py-0.5 bg-white border border-slate-200 rounded-md text-[11px] text-slate-700"
                            >
                              {item.productName} × {item.quantity} {item.unit} (
                              {formatDA(item.subtotal)} د.ج)
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Credit Transactions History (سجل الديون والتسديدات) */}
              <div>
                <h3 className="font-heading font-bold text-sm text-slate-800 mb-2.5">
                  سجل حركات الحساب (الديون والدفعات المسددة)
                </h3>
                {customerHistory.length === 0 ? (
                  <p className="text-xs text-slate-500 py-6 text-center bg-slate-50 rounded-xl">
                    لا توجد حركات مسجلة لهذا الزبون بعد.
                  </p>
                ) : (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {customerHistory.map((tx) => {
                      const isPayment = tx.type === "payment";
                      return (
                        <div
                          key={tx.id}
                          className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${
                            isPayment
                              ? "bg-emerald-50/50 border-emerald-200"
                              : "bg-amber-50/40 border-amber-200"
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <div
                              className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                                isPayment
                                  ? "bg-emerald-600 text-white"
                                  : "bg-amber-600 text-white"
                              }`}
                            >
                              {isPayment ? (
                                <ArrowDownLeft className="w-4 h-4" />
                              ) : (
                                <ArrowUpRight className="w-4 h-4" />
                              )}
                            </div>
                            <div>
                              <p className="text-xs font-bold text-slate-900">
                                {tx.note}
                              </p>
                              <p className="text-[11px] text-slate-500 num-tabular">
                                {new Date(tx.createdAt).toLocaleString("ar-DZ")}{" "}
                                | الرصيد بعدها: {formatDA(tx.balanceAfter)} د.ج
                              </p>
                            </div>
                          </div>

                          <span
                            className={`text-sm font-black num-tabular shrink-0 ${
                              isPayment ? "text-emerald-700" : "text-amber-800"
                            }`}
                          >
                            {isPayment ? "-" : "+"}
                            {formatDA(tx.amount)} د.ج
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal 1: Record Debt Repayment or Manual Debt */}
      {txModalMode && txCustomer && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">
                {txModalMode === "payment"
                  ? `تسديد دفعة كريدي: ${txCustomer.name}`
                  : `إضافة دين يدوي: ${txCustomer.name}`}
              </h3>
              <button
                type="button"
                onClick={() => setTxModalMode(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmTx} className="mt-4 space-y-4">
              <div className="bg-slate-50 rounded-xl p-3 flex items-center justify-between text-xs">
                <span className="font-bold text-slate-600">
                  الدين الحالي المسجل:
                </span>
                <span className="text-base font-black text-amber-800 num-tabular">
                  {formatDA(txCustomer.totalDebt)} د.ج
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {txModalMode === "payment"
                    ? "المبلغ المسدد الآن (د.ج) *"
                    : "المبلغ المضاف للكريدي (د.ج) *"}
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  step="0.5"
                  value={txAmount}
                  onChange={(e) => setTxAmount(e.target.value)}
                  placeholder="أدخل المبلغ بالدينار الجزائري..."
                  className="w-full h-11 px-3 bg-white rounded-xl border-2 border-emerald-500 text-base font-black num-tabular focus:outline-none"
                />
                {txModalMode === "payment" && txCustomer.totalDebt > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {[500, 1000, 2000, txCustomer.totalDebt].map((amt, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setTxAmount(String(amt))}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-700 hover:text-white text-slate-800 rounded-lg text-xs font-bold num-tabular transition-colors"
                      >
                        {amt === txCustomer.totalDebt
                          ? `كامل الدين (${formatDA(amt)} د.ج)`
                          : `${formatDA(amt)} د.ج`}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظة (اختياري)
                </label>
                <input
                  type="text"
                  value={txNote}
                  onChange={(e) => setTxNote(e.target.value)}
                  placeholder={
                    txModalMode === "payment"
                      ? "مثلاً: تسديد نقدي مع ابنه كمال"
                      : "مثلاً: باقي حساب قديم"
                  }
                  className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-xs font-medium focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setTxModalMode(null)}
                  className="px-4 h-10 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isProcessingTx}
                  className={`px-6 h-10 rounded-xl text-white text-xs font-bold ${
                    txModalMode === "payment"
                      ? "bg-emerald-700 hover:bg-emerald-800"
                      : "bg-amber-600 hover:bg-amber-700"
                  }`}
                >
                  {isProcessingTx
                    ? "جاري الحفظ..."
                    : txModalMode === "payment"
                    ? "تأكيد التسديد وخصم الدين"
                    : "تأكيد إضافة الدين"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Create New Customer in Credit Ledger */}
      {isNewCustModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-heading font-extrabold text-lg text-slate-900">
                فتح حساب زبون جديد في دفتر الكريدي
              </h3>
              <button
                type="button"
                onClick={() => setIsNewCustModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  اسم الزبون أو اللقب *
                </label>
                <input
                  type="text"
                  required
                  value={newCustName}
                  onChange={(e) => setNewCustName(e.target.value)}
                  placeholder="مثلاً: عمي رابح (العمارة 7)"
                  className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-medium focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رقم الهاتف (اختياري)
                </label>
                <input
                  type="text"
                  value={newCustPhone}
                  onChange={(e) => setNewCustPhone(e.target.value)}
                  placeholder="0550..."
                  className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-medium focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ملاحظة / العنوان (اختياري)
                </label>
                <input
                  type="text"
                  value={newCustNotes}
                  onChange={(e) => setNewCustNotes(e.target.value)}
                  placeholder="مثلاً: يسدد يوم 25 من كل شهر"
                  className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-medium focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    دين سابق عند فتح الحساب (د.ج)
                  </label>
                  <input
                    type="number"
                    value={newCustInitialDebt}
                    onChange={(e) => setNewCustInitialDebt(e.target.value)}
                    placeholder="0"
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold num-tabular focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    سقف الكريدي المسموح (د.ج)
                  </label>
                  <input
                    type="number"
                    value={newCustLimit}
                    onChange={(e) => setNewCustLimit(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 rounded-xl border border-slate-300 text-sm font-bold num-tabular focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsNewCustModalOpen(false)}
                  className="px-4 h-10 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isProcessingTx}
                  className="px-6 h-10 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold"
                >
                  {isProcessingTx ? "جاري الحفظ..." : "إضافة للدفتر"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
