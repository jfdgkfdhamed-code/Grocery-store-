"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import {
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  CheckCircle2,
  Banknote,
  BookOpen,
  Scale,
  Star,
  AlertTriangle,
  PauseCircle,
  PlayCircle,
  UserPlus,
  X,
  Printer,
  Sparkles,
  PackagePlus,
  Calculator,
  Eye,
  EyeOff,
  SplitSquareVertical,
} from "lucide-react";
import {
  Product,
  Customer,
  Sale,
  CartItem,
  HeldCart,
  CATEGORY_LIST,
  ARABIC_QUICK_LETTERS,
  formatDA,
  formatAlgerianCentimes,
  normalizeArabicForSearch,
} from "@/types/store";

interface PosTerminalViewProps {
  products: Product[];
  customers: Customer[];
  onSaleCompleted: (newSale: Sale) => void;
  onQuickSwitchTab: (tab: "pos" | "inventory" | "credit" | "dashboard") => void;
}

export default function PosTerminalView({
  products,
  customers,
  onSaleCompleted,
}: PosTerminalViewProps) {
  // Search & Filter states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("الكل");
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [quickFilterMode, setQuickFilterMode] = useState<
    "all" | "popular" | "weighted"
  >("all");

  // Multi-item Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [heldCarts, setHeldCarts] = useState<HeldCart[]>([]);

  // Quick Custom Item (سلعة حرة/خبز/خضر بدون تسجيل مسبق)
  const [showCustomItemBar, setShowCustomItemBar] = useState(false);
  const [customItemName, setCustomItemName] = useState("خبز / سلعة سريعة");
  const [customItemPrice, setCustomItemPrice] = useState("");

  // Checkout & Payment states
  const [paymentMethod, setPaymentMethod] = useState<
    "cash" | "credit" | "split"
  >("cash");
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(
    null
  );
  const [customerSearch, setCustomerSearch] = useState("");
  const [isAddingNewCustomer, setIsAddingNewCustomer] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState("");
  const [newCustomerPhone, setNewCustomerPhone] = useState("");
  const [splitPaidAmount, setSplitPaidAmount] = useState<string>("");
  const [invoiceNote, setInvoiceNote] = useState("");

  // Cash change calculator (حاسبة الصرف للزبون)
  const [receivedCash, setReceivedCash] = useState<string>("");
  const [showChangeCalc, setShowChangeCalc] = useState(false);

  // Privacy toggle for profit preview in cart
  const [showProfitPreview, setShowProfitPreview] = useState(false);

  // Submitting & Receipt Modal
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [completedSaleReceipt, setCompletedSaleReceipt] = useState<Sale | null>(
    null
  );
  const [lastAddedId, setLastAddedId] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut F2 or '/' to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "F2") {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Filter products rapidly by search query, initial letter, category, and mode
  const filteredProducts = useMemo(() => {
    const q = normalizeArabicForSearch(searchQuery);

    return products.filter((p) => {
      if (selectedCategory !== "الكل" && p.category !== selectedCategory) {
        return false;
      }
      if (quickFilterMode === "popular" && !p.isPopular) {
        return false;
      }
      if (quickFilterMode === "weighted" && !p.isWeighted) {
        return false;
      }
      if (selectedLetter) {
        const normName = normalizeArabicForSearch(p.name);
        const normLetter = normalizeArabicForSearch(selectedLetter);
        if (!normName.startsWith(normLetter)) {
          return false;
        }
      }
      if (q) {
        const normName = normalizeArabicForSearch(p.name);
        const normBrand = normalizeArabicForSearch(p.brand);
        const normCat = normalizeArabicForSearch(p.category);
        return (
          normName.includes(q) || normBrand.includes(q) || normCat.includes(q)
        );
      }
      return true;
    });
  }, [
    products,
    searchQuery,
    selectedCategory,
    selectedLetter,
    quickFilterMode,
  ]);

  // Map productId -> quantity in cart for instant card badges
  const cartQtyByProductId = useMemo(() => {
    const map = new Map<number, number>();
    for (const item of cart) {
      if (item.productId !== null) {
        map.set(item.productId, (map.get(item.productId) || 0) + item.quantity);
      }
    }
    return map;
  }, [cart]);

  // Add product to cart (or increment quantity)
  const addToCart = (product: Product, customQtyDelta?: number) => {
    setErrorMsg(null);
    const delta = customQtyDelta ?? 1;
    const key = `prod-${product.id}`;

    setLastAddedId(key);
    setTimeout(() => {
      setLastAddedId((prev) => (prev === key ? null : prev));
    }, 350);

    setCart((prev) => {
      const existingIndex = prev.findIndex((item) => item.cartKey === key);
      if (existingIndex > -1) {
        const updated = [...prev];
        const currentQty = updated[existingIndex].quantity;
        const newQty = Number((currentQty + delta).toFixed(3));
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: Math.max(0.05, newQty),
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            cartKey: key,
            productId: product.id,
            productName: product.name,
            brand: product.brand,
            unit: product.unit,
            isWeighted: product.isWeighted,
            quantity: Number(delta.toFixed(3)),
            unitPrice: product.sellingPrice,
            costPrice: product.costPrice,
            availableStock: product.stockQuantity,
          },
        ];
      }
    });
  };

  // Add custom quick item to cart
  const handleAddCustomItem = (overridePrice?: number) => {
    const price = overridePrice ?? Number(customItemPrice);
    if (!price || price <= 0) return;

    const name = customItemName.trim() || "سلعة متنوعة";
    const key = `custom-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    setCart((prev) => [
      ...prev,
      {
        cartKey: key,
        productId: null,
        productName: name,
        brand: "إضافة سريعة يدوية",
        unit: "حبة",
        isWeighted: false,
        quantity: 1,
        unitPrice: price,
        costPrice: Math.round(price * 0.82),
        availableStock: 999,
      },
    ]);

    setCustomItemPrice("");
  };

  // Update item quantity inside cart
  const updateCartQuantity = (cartKey: string, newQty: number) => {
    if (newQty <= 0) {
      setCart((prev) => prev.filter((item) => item.cartKey !== cartKey));
      return;
    }
    const rounded = Number(newQty.toFixed(3));
    setCart((prev) =>
      prev.map((item) =>
        item.cartKey === cartKey ? { ...item, quantity: rounded } : item
      )
    );
  };

  // Step quantity (+ or -)
  const stepCartQuantity = (item: CartItem, direction: 1 | -1) => {
    const step = item.isWeighted ? 0.25 : 1;
    const nextQty = Number((item.quantity + direction * step).toFixed(3));
    updateCartQuantity(item.cartKey, nextQty);
  };

  const removeFromCart = (cartKey: string) => {
    setCart((prev) => prev.filter((item) => item.cartKey !== cartKey));
  };

  const clearCart = () => {
    setCart([]);
    setReceivedCash("");
    setSplitPaidAmount("");
    setInvoiceNote("");
    setErrorMsg(null);
  };

  // Hold / Park current cart for a waiting customer
  const holdCurrentCart = () => {
    if (cart.length === 0) return;
    const newHeld: HeldCart = {
      id: `hold-${Date.now()}`,
      label: `زبون منتظر #${heldCarts.length + 1} (${cart.length} سلع)`,
      createdAt: new Date().toLocaleTimeString("ar-DZ", {
        hour: "2-digit",
        minute: "2-digit",
      }),
      items: cart,
    };
    setHeldCarts((prev) => [newHeld, ...prev]);
    clearCart();
  };

  const restoreHeldCart = (held: HeldCart) => {
    setCart(held.items);
    setHeldCarts((prev) => prev.filter((h) => h.id !== held.id));
  };

  // Cart Totals calculation
  const { cartTotalDA, cartTotalCostDA, cartProfitDA, totalUnitsCount } =
    useMemo(() => {
      let total = 0;
      let cost = 0;
      let units = 0;
      for (const item of cart) {
        total += item.quantity * item.unitPrice;
        cost += item.quantity * item.costPrice;
        units += item.isWeighted ? 1 : item.quantity;
      }
      total = Math.round(total * 100) / 100;
      cost = Math.round(cost * 100) / 100;
      return {
        cartTotalDA: total,
        cartTotalCostDA: cost,
        cartProfitDA: Math.round((total - cost) * 100) / 100,
        totalUnitsCount: Math.round(units * 100) / 100,
      };
    }, [cart]);

  // Filtered customers for credit picker
  const filteredCustomers = useMemo(() => {
    const q = normalizeArabicForSearch(customerSearch);
    if (!q) return customers;
    return customers.filter(
      (c) =>
        normalizeArabicForSearch(c.name).includes(q) ||
        c.phone.includes(q) ||
        normalizeArabicForSearch(c.notes).includes(q)
    );
  }, [customers, customerSearch]);

  const selectedCustomer = useMemo(
    () => customers.find((c) => c.id === selectedCustomerId) || null,
    [customers, selectedCustomerId]
  );

  // Calculate cash change to return to customer
  const cashChangeToReturn = useMemo(() => {
    const received = Number(receivedCash) || 0;
    if (received <= cartTotalDA) return 0;
    return Math.round((received - cartTotalDA) * 100) / 100;
  }, [receivedCash, cartTotalDA]);

  // Calculate split credit amount
  const calculatedCreditAmount = useMemo(() => {
    if (paymentMethod === "cash") return 0;
    if (paymentMethod === "credit") return cartTotalDA;
    const paid = Math.min(
      cartTotalDA,
      Math.max(0, Number(splitPaidAmount) || 0)
    );
    return Math.round((cartTotalDA - paid) * 100) / 100;
  }, [paymentMethod, cartTotalDA, splitPaidAmount]);

  // Confirm Checkout & Deduct Stock
  const handleConfirmSale = async () => {
    if (cart.length === 0) {
      setErrorMsg("السلة فارغة! أضف سلعة واحدة على الأقل لإتمام البيع.");
      return;
    }

    if (paymentMethod === "credit" || paymentMethod === "split") {
      if (!isAddingNewCustomer && !selectedCustomerId) {
        setErrorMsg(
          "يرجى اختيار الزبون من دفتر الكريدي أو الضغط على (+ زبون جديد)"
        );
        return;
      }
      if (isAddingNewCustomer && !newCustomerName.trim()) {
        setErrorMsg("يرجى كتابة اسم الزبون الجديد لتسجيل الفاتورة في الكريدي");
        return;
      }
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const res = await fetch("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: cart.map((item) => ({
            productId: item.productId,
            productName: item.productName,
            unit: item.unit,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            costPrice: item.costPrice,
          })),
          paymentMethod,
          paidAmount:
            paymentMethod === "split"
              ? Number(splitPaidAmount) || 0
              : paymentMethod === "cash"
              ? cartTotalDA
              : 0,
          customerId: isAddingNewCustomer ? null : selectedCustomerId,
          newCustomerName: isAddingNewCustomer ? newCustomerName : "",
          newCustomerPhone: isAddingNewCustomer ? newCustomerPhone : "",
          note: invoiceNote,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error || "حدث خطأ أثناء تأكيد الفاتورة");
        setIsSubmitting(false);
        return;
      }

      setCompletedSaleReceipt(data.sale);
      clearCart();
      setIsAddingNewCustomer(false);
      setNewCustomerName("");
      setNewCustomerPhone("");
      setPaymentMethod("cash");
      onSaleCompleted(data.sale);
    } catch {
      setErrorMsg("تعذر الاتصال بالخادم، يرجى المحاولة مرة أخرى.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Press Enter in search input to immediately add top matching product
  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && filteredProducts.length > 0) {
      e.preventDefault();
      addToCart(filteredProducts[0]);
      setSearchQuery("");
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
      {/* RIGHT PANEL (62% / 7 cols on lg): Rapid Product Discovery & Direct Multi-Item Selection */}
      <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-3">
        {/* Top Search & Quick Custom Item Bar */}
        <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs">
          <div className="flex flex-col sm:flex-row gap-2.5">
            {/* Instant Search Input */}
            <div className="relative flex-1">
              <Search className="w-5 h-5 text-emerald-700 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (selectedLetter) setSelectedLetter(null);
                }}
                onKeyDown={handleSearchKeyDown}
                placeholder="بحث سريع بدون باركود: اكتب اسم السلعة أو أول حرف (مثل: حليب، سكر، سيم، عدس)... اضغط Enter للإضافة"
                className="w-full h-12 pr-11 pl-20 bg-slate-50 focus:bg-white rounded-xl border-2 border-slate-200 focus:border-emerald-600 focus:outline-none text-base font-medium text-slate-900 placeholder:text-slate-400 transition-all"
              />
              {searchQuery ? (
                <button
                  type="button"
                  onClick={() => setSearchQuery("")}
                  className="absolute left-3 top-1/2 -translate-y-1/2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg px-2 py-1 text-xs font-bold"
                >
                  مسح
                </button>
              ) : (
                <span className="hidden sm:inline-flex items-center gap-1 absolute left-3 top-1/2 -translate-y-1/2 bg-slate-200/70 text-slate-600 text-[11px] font-mono px-2 py-0.5 rounded-md">
                  F2
                </span>
              )}
            </div>

            {/* Quick Unlisted / Custom Item Toggle Button */}
            <button
              type="button"
              onClick={() => setShowCustomItemBar((v) => !v)}
              className={`h-12 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 border-2 transition-all shrink-0 ${
                showCustomItemBar
                  ? "bg-amber-600 text-white border-amber-600 shadow-xs"
                  : "bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100"
              }`}
            >
              <PackagePlus className="w-4 h-4" />
              <span>+ سلعة حرة / خبز</span>
            </button>
          </div>

          {/* Expandable Quick Unlisted Item Bar */}
          {showCustomItemBar && (
            <div className="mt-3 pt-3 border-t border-slate-200 bg-amber-50/70 -mx-3 -mb-3 p-3 rounded-b-xl flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-amber-900">
                إضافة سريعة للفاتورة (خضر / خبز / سلعة غير مسجلة):
              </span>
              <input
                type="text"
                value={customItemName}
                onChange={(e) => setCustomItemName(e.target.value)}
                placeholder="اسم السلعة (مثلاً: خبز، خضر، كيس...)"
                className="h-9 px-3 bg-white rounded-lg border border-amber-300 text-sm font-medium w-44 focus:outline-none focus:border-amber-600"
              />
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={customItemPrice}
                  onChange={(e) => setCustomItemPrice(e.target.value)}
                  placeholder="السعر د.ج"
                  className="h-9 px-3 bg-white rounded-lg border border-amber-300 text-sm font-bold num-tabular w-28 focus:outline-none focus:border-amber-600"
                />
                <button
                  type="button"
                  onClick={() => handleAddCustomItem()}
                  className="h-9 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold"
                >
                  أضف للسلة
                </button>
              </div>
              <div className="flex items-center gap-1 mr-auto">
                <span className="text-[11px] text-amber-800 font-medium ml-1">
                  مبالغ سريعة:
                </span>
                {[15, 30, 50, 100, 150, 200].map((quickPrice) => (
                  <button
                    key={quickPrice}
                    type="button"
                    onClick={() => handleAddCustomItem(quickPrice)}
                    className="h-8 px-2.5 bg-white hover:bg-amber-600 hover:text-white text-amber-950 border border-amber-300 rounded-lg text-xs font-bold num-tabular transition-colors"
                  >
                    +{quickPrice} د.ج
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Arabic First-Letter Quick Index Bar (شريط الحروف السريع) */}
          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-xs font-bold text-slate-500 shrink-0 ml-1">
              أول حرف:
            </span>
            <button
              type="button"
              onClick={() => setSelectedLetter(null)}
              className={`h-8 px-3 rounded-lg text-xs font-bold shrink-0 transition-all ${
                selectedLetter === null
                  ? "bg-slate-900 text-white shadow-2xs"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              الكل
            </button>
            {ARABIC_QUICK_LETTERS.map((letter) => {
              const isActive = selectedLetter === letter;
              return (
                <button
                  key={letter}
                  type="button"
                  onClick={() =>
                    setSelectedLetter(isActive ? null : letter)
                  }
                  className={`w-8 h-8 rounded-lg text-sm font-bold shrink-0 flex items-center justify-center transition-all ${
                    isActive
                      ? "bg-emerald-700 text-white shadow-xs scale-105"
                      : "bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200/70"
                  }`}
                >
                  {letter}
                </button>
              );
            })}
          </div>

          {/* Category Pills & Mode Filters */}
          <div className="mt-2.5 flex items-center gap-1.5 overflow-x-auto pb-1">
            {/* Quick Mode Pills */}
            <button
              type="button"
              onClick={() => {
                setQuickFilterMode("all");
                setSelectedCategory("الكل");
              }}
              className={`h-9 px-3.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 transition-all ${
                quickFilterMode === "all" && selectedCategory === "الكل"
                  ? "bg-emerald-700 text-white shadow-xs"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              <span>جميع السلع ({products.length})</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setQuickFilterMode(
                  quickFilterMode === "popular" ? "all" : "popular"
                )
              }
              className={`h-9 px-3.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 transition-all ${
                quickFilterMode === "popular"
                  ? "bg-amber-500 text-white shadow-xs"
                  : "bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100"
              }`}
            >
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>الأكثر طلباً يومياً</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setQuickFilterMode(
                  quickFilterMode === "weighted" ? "all" : "weighted"
                )
              }
              className={`h-9 px-3.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 transition-all ${
                quickFilterMode === "weighted"
                  ? "bg-sky-600 text-white shadow-xs"
                  : "bg-sky-50 text-sky-900 border border-sky-200 hover:bg-sky-100"
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
              <span>سلع الميزان (كغ)</span>
            </button>

            <div className="h-5 w-px bg-slate-200 mx-1 shrink-0" />

            {CATEGORY_LIST.filter((c) => c !== "الكل").map((category) => {
              const isSelected = selectedCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  onClick={() =>
                    setSelectedCategory(isSelected ? "الكل" : category)
                  }
                  className={`h-9 px-3.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                    isSelected
                      ? "bg-emerald-700 text-white shadow-xs"
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Held / Parked Carts Bar (if any waiting customer) */}
        {heldCarts.length > 0 && (
          <div className="bg-amber-50 border border-amber-300 rounded-xl p-2.5 flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
              <PauseCircle className="w-4 h-4 text-amber-700" />
              فواتير معلقة بالانتظار ({heldCarts.length}):
            </span>
            {heldCarts.map((held) => (
              <button
                key={held.id}
                type="button"
                onClick={() => restoreHeldCart(held)}
                className="px-3 py-1.5 bg-white hover:bg-amber-600 hover:text-white text-amber-950 border border-amber-300 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors"
              >
                <PlayCircle className="w-3.5 h-3.5" />
                <span>{held.label}</span>
                <span className="opacity-70 text-[10px]">({held.createdAt})</span>
              </button>
            ))}
          </div>
        )}

        {/* Product Grid: High-Visibility Touch/Click Tiles */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-10 text-center">
            <p className="text-base font-bold text-slate-700 mb-1">
              لا توجد سلعة مطابقة للبحث &ldquo;{searchQuery || selectedLetter}&rdquo;
            </p>
            <p className="text-xs text-slate-500 mb-4">
              يمكنك مسح فلتر البحث أو استخدام زر (+ سلعة حرة / خبز) لإضافة أي غرض فوراً للسلة.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery("");
                setSelectedLetter(null);
                setSelectedCategory("الكل");
                setQuickFilterMode("all");
              }}
              className="px-4 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold"
            >
              إظهار جميع السلع
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-2.5">
            {filteredProducts.map((product) => {
              const qtyInCart = cartQtyByProductId.get(product.id) || 0;
              const isLowStock =
                product.stockQuantity > 0 &&
                product.stockQuantity <= product.minStockAlert;
              const isOutOfStock = product.stockQuantity <= 0;
              const isJustAdded = lastAddedId === `prod-${product.id}`;

              return (
                <div
                  key={product.id}
                  onClick={() => addToCart(product)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      addToCart(product);
                    }
                  }}
                  className={`group relative rounded-xl p-3 bg-white border-2 transition-all cursor-pointer select-none flex flex-col justify-between min-h-[138px] ${
                    qtyInCart > 0
                      ? "border-emerald-600 bg-emerald-50/25 shadow-sm ring-2 ring-emerald-500/20"
                      : "border-slate-200/90 hover:border-emerald-500 hover:shadow-sm"
                  } ${isJustAdded ? "scale-[0.97]" : "active:scale-[0.98]"}`}
                >
                  {/* Top Row: Unit / Category Pill & Stock Badge */}
                  <div>
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold ${
                          product.isWeighted
                            ? "bg-sky-100 text-sky-900"
                            : "bg-slate-100 text-slate-700"
                        }`}
                      >
                        {product.isWeighted && <Scale className="w-3 h-3" />}
                        {product.unit}
                      </span>

                      <span
                        className={`px-2 py-0.5 rounded-md text-[11px] font-bold num-tabular ${
                          isOutOfStock
                            ? "bg-red-100 text-red-800"
                            : isLowStock
                            ? "bg-amber-100 text-amber-900"
                            : "bg-emerald-50 text-emerald-800"
                        }`}
                      >
                        {isOutOfStock
                          ? "نفد (0)"
                          : isLowStock
                          ? `تنبيه: ${product.stockQuantity}`
                          : `مخزون: ${product.stockQuantity}`}
                      </span>
                    </div>

                    {/* Product Name & Brand */}
                    <h3 className="font-heading font-bold text-slate-900 text-sm sm:text-[15px] leading-snug line-clamp-2 group-hover:text-emerald-800 transition-colors">
                      {product.name}
                    </h3>
                    {product.brand && (
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        {product.brand}
                      </p>
                    )}
                  </div>

                  {/* Bottom Row: Price in DA + Active Cart Badge or Weight Presets */}
                  <div className="mt-2.5 pt-2 border-t border-slate-100">
                    <div className="flex items-baseline justify-between">
                      <div>
                        <span className="text-lg font-extrabold text-emerald-800 num-tabular">
                          {formatDA(product.sellingPrice)}
                        </span>
                        <span className="text-xs font-bold text-emerald-700 mr-1">
                          د.ج
                        </span>
                        {product.isWeighted && (
                          <span className="text-[10px] text-slate-500 font-medium mr-0.5">
                            / كغ
                          </span>
                        )}
                      </div>

                      {qtyInCart > 0 ? (
                        <div
                          onClick={(e) => e.stopPropagation()}
                          className="flex items-center gap-1 bg-emerald-700 text-white rounded-lg px-1.5 py-0.5 shadow-2xs"
                        >
                          <button
                            type="button"
                            onClick={() =>
                              updateCartQuantity(
                                `prod-${product.id}`,
                                qtyInCart - (product.isWeighted ? 0.25 : 1)
                              )
                            }
                            className="w-5 h-5 rounded hover:bg-emerald-800 flex items-center justify-center font-bold"
                            title="إنقاص"
                          >
                            -
                          </button>
                          <span className="text-xs font-extrabold num-tabular px-1">
                            {qtyInCart}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              addToCart(
                                product,
                                product.isWeighted ? 0.25 : 1
                              )
                            }
                            className="w-5 h-5 rounded hover:bg-emerald-800 flex items-center justify-center font-bold"
                            title="زيادة"
                          >
                            +
                          </button>
                        </div>
                      ) : (
                        <span className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-emerald-700 group-hover:text-white text-slate-700 flex items-center justify-center transition-colors">
                          <Plus className="w-4 h-4" />
                        </span>
                      )}
                    </div>

                    {/* Direct Quick Weight Buttons on Card for Weighted Goods (عدس/لوبيا/حمص/أرز/زيتون) */}
                    {product.isWeighted && (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="mt-2 grid grid-cols-3 gap-1"
                      >
                        {[
                          { label: "+ربع رطل", qty: 0.25 },
                          { label: "+رطل (0.5)", qty: 0.5 },
                          { label: "+1 كغ", qty: 1 },
                        ].map((preset) => (
                          <button
                            key={preset.qty}
                            type="button"
                            onClick={() => addToCart(product, preset.qty)}
                            className="py-1 px-1 bg-sky-50 hover:bg-sky-600 hover:text-white text-sky-900 border border-sky-200 rounded text-[10px] font-bold transition-colors text-center"
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* LEFT PANEL (38% / 5 cols on lg): Active Multi-Item Cart (سلة المشتريات - Panier) & Instant Checkout */}
      <div className="lg:col-span-5 xl:col-span-4 lg:sticky lg:top-20 flex flex-col bg-white rounded-2xl border-2 border-slate-200 shadow-md overflow-hidden">
        {/* Cart Header */}
        <div className="bg-slate-900 text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center shadow-inner">
              <ShoppingCart className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-heading font-bold text-base">
                  سلة المشتريات (Panier)
                </h2>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full text-xs font-bold num-tabular">
                  {cart.length} {cart.length === 1 ? "مادة" : "مواد"}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                إجمالي القطع والأوزان: {totalUnitsCount} | بيع متعدد السلع
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {cart.length > 0 && (
              <>
                <button
                  type="button"
                  onClick={holdCurrentCart}
                  title="تعليق الفاتورة مؤقتاً لخدمة زبون آخر"
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-amber-600 text-amber-300 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors"
                >
                  <PauseCircle className="w-3.5 h-3.5" />
                  <span>تعليق</span>
                </button>
                <button
                  type="button"
                  onClick={clearCart}
                  title="إفراغ السلة"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-600 text-slate-300 hover:text-white transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Cart Items Scrollable Area */}
        <div className="max-h-[340px] overflow-y-auto divide-y divide-slate-100 bg-slate-50/40">
          {cart.length === 0 ? (
            <div className="py-12 px-6 text-center">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center mx-auto mb-3">
                <ShoppingCart className="w-7 h-7" />
              </div>
              <h3 className="font-heading font-bold text-slate-800 text-base mb-1">
                السلة جاهزة لاستقبال مشتريات الزبون
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                اضغط على أي سلعة من القائمة أو ابحث بأول حرف لتجميع عدة أغراض في نفس الفاتورة وتعديل كمياتها فوراً.
              </p>
            </div>
          ) : (
            cart.map((item, idx) => {
              const itemSubtotal =
                Math.round(item.quantity * item.unitPrice * 100) / 100;

              return (
                <div
                  key={item.cartKey}
                  className="p-3 bg-white hover:bg-slate-50/80 transition-colors"
                >
                  {/* Row 1: Item Name, Unit Price & Subtotal */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-start gap-2 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[11px] font-bold num-tabular flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <div className="min-w-0">
                        <h4 className="font-heading font-bold text-slate-900 text-sm truncate">
                          {item.productName}
                        </h4>
                        <p className="text-[11px] text-slate-500 num-tabular">
                          سعر الـ {item.unit}:{" "}
                          <strong className="text-slate-700">
                            {formatDA(item.unitPrice)} د.ج
                          </strong>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-left">
                        <span className="text-base font-extrabold text-emerald-800 num-tabular">
                          {formatDA(itemSubtotal)}
                        </span>
                        <span className="text-xs font-bold text-emerald-700 mr-1">
                          د.ج
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFromCart(item.cartKey)}
                        className="w-7 h-7 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 flex items-center justify-center transition-colors"
                        title="حذف من السلة"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Row 2: Quantity / Weight Stepper & Quick Presets */}
                  <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-100/80 rounded-xl p-1.5">
                    {/* Stepper Controls */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => stepCartQuantity(item, -1)}
                        className="w-8 h-8 rounded-lg bg-white hover:bg-red-50 hover:text-red-700 border border-slate-200 text-slate-800 flex items-center justify-center font-bold shadow-2xs transition-colors"
                        title="إنقاص الكمية"
                      >
                        <Minus className="w-4 h-4" />
                      </button>

                      <div className="flex items-center bg-white border border-slate-300 rounded-lg px-2 h-8">
                        <input
                          type="number"
                          step={item.isWeighted ? "0.05" : "1"}
                          min="0.05"
                          value={item.quantity}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            if (!isNaN(val) && val > 0) {
                              updateCartQuantity(item.cartKey, val);
                            }
                          }}
                          className="w-14 text-center font-extrabold text-sm text-slate-900 num-tabular focus:outline-none"
                        />
                        <span className="text-[11px] font-bold text-slate-500">
                          {item.unit}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => stepCartQuantity(item, 1)}
                        className="w-8 h-8 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white flex items-center justify-center font-bold shadow-2xs transition-colors"
                        title="زيادة الكمية"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Quick Multipliers / Weight Presets */}
                    {item.isWeighted ? (
                      <div className="flex items-center gap-1">
                        {[
                          { label: "ربع (0.25)", val: 0.25 },
                          { label: "رطل (0.5)", val: 0.5 },
                          { label: "1 كغ", val: 1 },
                          { label: "2 كغ", val: 2 },
                        ].map((w) => (
                          <button
                            key={w.val}
                            type="button"
                            onClick={() =>
                              updateCartQuantity(item.cartKey, w.val)
                            }
                            className={`px-2 py-1 rounded-md text-[10px] font-bold transition-colors ${
                              item.quantity === w.val
                                ? "bg-sky-700 text-white"
                                : "bg-white text-slate-700 hover:bg-sky-50 border border-slate-200"
                            }`}
                          >
                            {w.label}
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="flex items-center gap-1">
                        {[
                          { label: "+2", delta: 2 },
                          { label: "+5", delta: 5 },
                          { label: "+6", delta: 6 },
                        ].map((m) => (
                          <button
                            key={m.delta}
                            type="button"
                            onClick={() =>
                              updateCartQuantity(
                                item.cartKey,
                                item.quantity + m.delta
                              )
                            }
                            className="px-2 py-1 rounded-md bg-white hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200 text-slate-700 text-[11px] font-bold num-tabular transition-colors"
                          >
                            {m.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sticky Checkout & Payment Dock */}
        <div className="p-4 bg-white border-t-2 border-slate-200 space-y-3">
          {/* Grand Total Banner in Algerian Dinar & Centimes */}
          <div className="bg-gradient-to-l from-slate-900 via-slate-800 to-emerald-950 text-white rounded-xl p-3.5 shadow-inner">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-300">
                المجموع الكلي للفاتورة (Total à Payer):
              </span>
              <button
                type="button"
                onClick={() => setShowProfitPreview((v) => !v)}
                className="text-[11px] text-emerald-300/90 hover:text-emerald-200 flex items-center gap-1"
                title="إظهار/إخفاء هامش ربح هذه السلة"
              >
                {showProfitPreview ? (
                  <>
                    <EyeOff className="w-3.5 h-3.5" />
                    <span>ربح السلة: +{formatDA(cartProfitDA)} د.ج</span>
                  </>
                ) : (
                  <>
                    <Eye className="w-3.5 h-3.5" />
                    <span>هامش الربح</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex items-baseline justify-between">
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl font-black text-emerald-400 num-tabular tracking-tight">
                  {formatDA(cartTotalDA)}
                </span>
                <span className="text-sm font-bold text-white">د.ج (DA)</span>
              </div>

              <div className="text-left">
                <span className="inline-block bg-white/10 text-amber-300 px-2.5 py-0.5 rounded-lg text-xs font-bold">
                  {formatAlgerianCentimes(cartTotalDA)}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Method Selector: Cash (كاش) vs Credit (دفتر الكريدي) vs Split (دفع جزئي) */}
          <div>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => setPaymentMethod("cash")}
                className={`py-2.5 px-2 rounded-xl font-bold text-xs flex flex-col items-center justify-center gap-1 border-2 transition-all ${
                  paymentMethod === "cash"
                    ? "bg-emerald-700 text-white border-emerald-700 shadow-xs"
                    : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                }`}
              >
                <Banknote className="w-4 h-4" />
                <span>دفع نقدي (كاش)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod("credit")}
                className={`py-2.5 px-2 rounded-xl font-bold text-xs flex flex-col items-center justify-center gap-1 border-2 transition-all ${
                  paymentMethod === "credit"
                    ? "bg-amber-600 text-white border-amber-600 shadow-xs"
                    : "bg-amber-50/60 text-amber-950 border-amber-200 hover:bg-amber-100"
                }`}
              >
                <BookOpen className="w-4 h-4" />
                <span>دفتر الكريدي</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod("split")}
                className={`py-2.5 px-2 rounded-xl font-bold text-xs flex flex-col items-center justify-center gap-1 border-2 transition-all ${
                  paymentMethod === "split"
                    ? "bg-sky-700 text-white border-sky-700 shadow-xs"
                    : "bg-sky-50/60 text-sky-950 border-sky-200 hover:bg-sky-100"
                }`}
              >
                <SplitSquareVertical className="w-4 h-4" />
                <span>تسبقة + كريدي</span>
              </button>
            </div>
          </div>

          {/* Conditional Section 1: Cash Change Calculator (حاسبة الصرف للزبون) */}
          {paymentMethod === "cash" && cartTotalDA > 0 && (
            <div className="bg-slate-50 rounded-xl p-2.5 border border-slate-200">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setShowChangeCalc((v) => !v)}
                  className="text-xs font-bold text-slate-700 hover:text-emerald-800 flex items-center gap-1.5"
                >
                  <Calculator className="w-3.5 h-3.5 text-emerald-700" />
                  <span>حاسبة الصرف للزبون (اختياري)</span>
                </button>
                {Number(receivedCash) > 0 && (
                  <span className="text-xs font-extrabold text-emerald-800 num-tabular">
                    الباقي للزبون: {formatDA(cashChangeToReturn)} د.ج
                  </span>
                )}
              </div>

              {showChangeCalc && (
                <div className="mt-2 pt-2 border-t border-slate-200 space-y-2">
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={receivedCash}
                      onChange={(e) => setReceivedCash(e.target.value)}
                      placeholder="المبلغ المستلم من الزبون..."
                      className="flex-1 h-8 px-2.5 bg-white rounded-lg border border-slate-300 text-xs font-bold num-tabular"
                    />
                    {[200, 500, 1000, 2000].map((note) => (
                      <button
                        key={note}
                        type="button"
                        onClick={() => setReceivedCash(String(note))}
                        className="h-8 px-2 bg-white hover:bg-emerald-700 hover:text-white border border-slate-300 rounded-lg text-[11px] font-bold num-tabular transition-colors"
                      >
                        {note}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Conditional Section 2: Credit / Split Customer Selector */}
          {(paymentMethod === "credit" || paymentMethod === "split") && (
            <div className="bg-amber-50/80 border-2 border-amber-300 rounded-xl p-3 space-y-2.5">
              {paymentMethod === "split" && (
                <div>
                  <label className="block text-xs font-bold text-amber-950 mb-1">
                    المبلغ المدفوع كاش الآن (د.ج):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={splitPaidAmount}
                      onChange={(e) => setSplitPaidAmount(e.target.value)}
                      placeholder="مثلاً: 500"
                      className="flex-1 h-9 px-3 bg-white rounded-lg border border-amber-400 text-sm font-bold num-tabular focus:outline-none"
                    />
                    <div className="text-xs font-bold text-amber-900 bg-amber-100 px-2.5 py-1.5 rounded-lg num-tabular">
                      الباقي للكريدي: {formatDA(calculatedCreditAmount)} د.ج
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-950">
                  اختر الزبون لتسجيل الكريدي:
                </span>
                <button
                  type="button"
                  onClick={() => setIsAddingNewCustomer((v) => !v)}
                  className="text-xs font-bold text-amber-900 bg-white hover:bg-amber-200 border border-amber-300 px-2.5 py-1 rounded-lg flex items-center gap-1 transition-colors"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>
                    {isAddingNewCustomer ? "اختيار زبون مسجل" : "+ زبون جديد"}
                  </span>
                </button>
              </div>

              {isAddingNewCustomer ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={newCustomerName}
                    onChange={(e) => setNewCustomerName(e.target.value)}
                    placeholder="اسم الزبون الثلاثي أو اللقب (مطلوب)..."
                    className="w-full h-9 px-3 bg-white rounded-lg border border-amber-300 text-xs font-bold focus:outline-none focus:border-amber-600"
                  />
                  <input
                    type="text"
                    value={newCustomerPhone}
                    onChange={(e) => setNewCustomerPhone(e.target.value)}
                    placeholder="رقم الهاتف أو رقم العمارة (اختياري)..."
                    className="w-full h-9 px-3 bg-white rounded-lg border border-amber-300 text-xs font-medium focus:outline-none focus:border-amber-600"
                  />
                </div>
              ) : (
                <>
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder="ابحث عن اسم الزبون في دفتر الكريدي..."
                    className="w-full h-9 px-3 bg-white rounded-lg border border-amber-300 text-xs font-medium focus:outline-none focus:border-amber-600"
                  />

                  <div className="max-h-32 overflow-y-auto space-y-1 pr-0.5">
                    {filteredCustomers.map((cust) => {
                      const isSelected = selectedCustomerId === cust.id;
                      return (
                        <button
                          key={cust.id}
                          type="button"
                          onClick={() => setSelectedCustomerId(cust.id)}
                          className={`w-full text-right px-2.5 py-2 rounded-lg text-xs flex items-center justify-between transition-all ${
                            isSelected
                              ? "bg-amber-600 text-white font-bold shadow-2xs"
                              : "bg-white hover:bg-amber-100 text-slate-800 border border-amber-200/80"
                          }`}
                        >
                          <span className="truncate">{cust.name}</span>
                          <span
                            className={`num-tabular font-bold shrink-0 mr-2 ${
                              isSelected ? "text-amber-100" : "text-amber-900"
                            }`}
                          >
                            دين: {formatDA(cust.totalDebt)} د.ج
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {selectedCustomer && (
                    <div className="bg-white rounded-lg p-2 border border-amber-300 flex items-center justify-between text-xs">
                      <span className="text-slate-600 font-medium">
                        إجمالي الدين الجديد بعد الفاتورة:
                      </span>
                      <span className="font-extrabold text-amber-900 num-tabular">
                        {formatDA(
                          selectedCustomer.totalDebt + calculatedCreditAmount
                        )}{" "}
                        د.ج
                      </span>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* Error Alert */}
          {errorMsg && (
            <div className="bg-red-50 border border-red-300 text-red-800 rounded-xl p-2.5 text-xs font-bold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Primary Confirm Sale & Deduct Stock Button */}
          <button
            type="button"
            disabled={isSubmitting || cart.length === 0}
            onClick={handleConfirmSale}
            className={`w-full h-14 rounded-xl font-heading font-extrabold text-base flex items-center justify-center gap-2.5 shadow-md transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              paymentMethod === "cash"
                ? "bg-emerald-700 hover:bg-emerald-800 text-white"
                : paymentMethod === "credit"
                ? "bg-amber-600 hover:bg-amber-700 text-white"
                : "bg-sky-700 hover:bg-sky-800 text-white"
            }`}
          >
            <CheckCircle2 className="w-5 h-5" />
            {isSubmitting ? (
              <span>جاري تأكيد الفاتورة وخصم المخزون...</span>
            ) : paymentMethod === "cash" ? (
              <span>
                تأكيد البيع نقداً وخصم المخزون ({formatDA(cartTotalDA)} د.ج)
              </span>
            ) : paymentMethod === "credit" ? (
              <span>
                تسجيل في دفتر الكريدي وخصم المخزون ({formatDA(cartTotalDA)} د.ج)
              </span>
            ) : (
              <span>
                تأكيد الدفع الجزئي والكريدي ({formatDA(cartTotalDA)} د.ج)
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Receipt / Completed Invoice Modal (تذكرة البيع الفورية) */}
      {completedSaleReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2 text-emerald-700">
                <Sparkles className="w-5 h-5" />
                <h3 className="font-heading font-extrabold text-lg">
                  تم تأكيد البيع وخصم المخزون بنجاح!
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCompletedSaleReceipt(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Receipt Content */}
            <div className="my-4 bg-slate-50 rounded-xl p-4 border border-dashed border-slate-300 space-y-3">
              <div className="text-center border-b border-slate-200 pb-2">
                <p className="font-heading font-bold text-sm text-slate-900">
                  محل المواد الغذائية العامة - Alimentation Générale
                </p>
                <p className="text-xs text-slate-500 num-tabular">
                  فاتورة رقم: {completedSaleReceipt.invoiceNumber} |{" "}
                  {new Date(completedSaleReceipt.createdAt).toLocaleString(
                    "ar-DZ"
                  )}
                </p>
              </div>

              <div className="space-y-1.5 max-h-48 overflow-y-auto text-xs">
                {completedSaleReceipt.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between py-1 border-b border-slate-200/60"
                  >
                    <div>
                      <span className="font-bold text-slate-800">
                        {item.productName}
                      </span>
                      <span className="text-slate-500 mr-1 num-tabular">
                        ({item.quantity} {item.unit} ×{" "}
                        {formatDA(item.unitPrice)})
                      </span>
                    </div>
                    <span className="font-extrabold text-slate-900 num-tabular">
                      {formatDA(item.subtotal)} د.ج
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-300 space-y-1">
                <div className="flex items-center justify-between text-base font-extrabold text-emerald-800">
                  <span>المجموع الكلي:</span>
                  <span className="num-tabular">
                    {formatDA(completedSaleReceipt.totalAmount)} د.ج
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <span>طريقة الدفع:</span>
                  <span className="font-bold">
                    {completedSaleReceipt.paymentMethod === "cash"
                      ? "نقداً (كاش)"
                      : completedSaleReceipt.paymentMethod === "credit"
                      ? `كريدي (${completedSaleReceipt.customerName})`
                      : `دفع جزئي (${formatDA(
                          completedSaleReceipt.paidAmount
                        )} كاش + ${formatDA(
                          completedSaleReceipt.creditAmount
                        )} كريدي)`}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="flex-1 h-11 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة الوصل</span>
              </button>
              <button
                type="button"
                onClick={() => setCompletedSaleReceipt(null)}
                className="flex-2 h-11 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 transition-colors"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>فاتورة زبون جديد</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
